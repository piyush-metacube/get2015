skillfinderapp.controller('UserController', ['$scope', function($scope) {
	$scope.username = 'home';
}]);

skillfinderapp.controller('AboutController', ['$scope', function($scope) {
	$scope.username = 'about';
}]);