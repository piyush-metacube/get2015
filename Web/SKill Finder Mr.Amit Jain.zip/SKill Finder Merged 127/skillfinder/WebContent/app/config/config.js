skillfinderapp.config(function($routeProvider) {
	$routeProvider.when("/", {
		templateUrl : "Home.html",
		controller : "HomeController",
	}).when("/about", {
		templateUrl : "about.html",
		controller : "AboutController",
	});
})