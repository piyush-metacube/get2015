/**
 * 
 */
package com.skillfinder.service;

import java.util.List;

import com.skillfinder.model.Skill;
import com.skillfinder.model.User;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
public interface SkillService {
	public DatabaseOperationStatus add(Skill skill);

	public DatabaseOperationStatus update(User user, Skill skill);

	public DatabaseOperationStatus delete(Skill skill);

	public List<Skill> getSkill(User user);

	public boolean checkSkill(Skill skill);
	
	public List<User> search(String inputString);
	
}
