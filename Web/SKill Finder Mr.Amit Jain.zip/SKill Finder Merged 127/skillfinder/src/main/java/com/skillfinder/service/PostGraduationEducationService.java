/**
 * 
 */
package com.skillfinder.service;

import java.util.List;

import com.skillfinder.model.PostGraduateEducation;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
public interface PostGraduationEducationService {
	public DatabaseOperationStatus add(PostGraduateEducation education );
	public DatabaseOperationStatus update(PostGraduateEducation education );
	//public void delete(int id);
	public PostGraduateEducation getEducation(int id);
	public List<PostGraduateEducation> getAllEducation();
}
