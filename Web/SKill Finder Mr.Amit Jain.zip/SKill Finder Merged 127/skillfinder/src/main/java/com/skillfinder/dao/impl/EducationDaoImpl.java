/**
 * 
 */
package com.skillfinder.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.EducationDao;
import com.skillfinder.model.CommonData;
import com.skillfinder.model.Education;
import com.skillfinder.model.User;
import com.skillfinder.model.Work;

/**
 * @author priyamvada
 *
 */
@Repository
public class EducationDaoImpl implements EducationDao {

	@Autowired
	private SessionFactory session;

	@Override
	public void add(User user, Education education) {
		session.getCurrentSession().save(education);
	}

	@Override
	public void update(Education education) {
		session.getCurrentSession().update(education);
	}

	@Override
	public void delete(Education education) {
		session.getCurrentSession().delete(getEducation(education));
	}

	@Override
	public Education getEducation(Education education) {
		return (Education) session.getCurrentSession().get(Education.class,
				education.getId());
	}

	@Override
	public Education getEducation(User user) {
		Criteria criteria1 = session.getCurrentSession().createCriteria(
				Education.class);
		Criteria criteria2 = criteria1.createCriteria("user");
		criteria2.add(Restrictions.eq("userName", user.getUserName()));
		return ((Education) criteria2.uniqueResult());
	}

}
