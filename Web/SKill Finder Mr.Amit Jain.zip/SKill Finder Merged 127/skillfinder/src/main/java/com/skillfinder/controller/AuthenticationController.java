package com.skillfinder.controller;

import com.skillfinder.model.requests.UserCredential;
import com.skillfinder.model.responses.GoogleAuthenticationPojo;
import com.skillfinder.model.responses.LoginResponse;
import com.skillfinder.model.responses.OperationResponse;

/**
 * @author Piyush Sharma
 *
 */
public interface AuthenticationController {

	/**
	 * @param userName
	 * @return OperationResponse
	 */
	public OperationResponse checkUserExitence(String userName);

	/**
	 * @param userName
	 * @return OperationResponse
	 */
	public OperationResponse forgotPassword(String userName);

	/**
	 * @param loginRequest
	 * @return LoginResponse
	 */
	public LoginResponse login(UserCredential loginRequest);

	/**
	 * @param googleAuthenticationPojo
	 * @return LoginResponse
	 */
	public LoginResponse googleOauthLogin(
			GoogleAuthenticationPojo googleAuthenticationPojo);

}