package com.skillfinder.controller;

import java.util.List;

import com.skillfinder.model.requests.CertificateRequest;
import com.skillfinder.model.requests.CommonDetailsRequest;
import com.skillfinder.model.requests.EducationDataRequest;
import com.skillfinder.model.requests.SkillRequest;
import com.skillfinder.model.requests.UserCredential;
import com.skillfinder.model.requests.WorkExperienceRequest;
import com.skillfinder.model.responses.OperationResponse;

/**
 * @author Piyush Sharma
 *
 */
public interface SaveAccountDetailsController {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.SaveAccountDetailsCont#saveCredentials
	 * (com.skillfinder.model.requests.UserCredential)
	 */
	/**
	 * @param userCredential
	 * @return OperationResponse
	 */
	public OperationResponse saveCredentials(UserCredential userCredential);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.SaveAccountDetailsCont#saveWorkExperience
	 * (com.skillfinder.model.requests.WorkExperienceRequest)
	 */
	/**
	 * @param workExperienceRequest
	 * @return OperationResponse
	 */
	public OperationResponse saveWorkExperience(
			WorkExperienceRequest workExperienceRequest);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.SaveAccountDetailsCont#saveEducation(
	 * com.skillfinder.model.requests.EducationDataRequest)
	 */
	/**
	 * @param educationDataRequest
	 * @return OperationResponse
	 */
	public OperationResponse saveEducation(
			EducationDataRequest educationDataRequest);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.SaveAccountDetailsCont#saveCommonData
	 * (com.skillfinder.model.requests.CommonDetailsRequest)
	 */
	/**
	 * @param commonDetailsRequest
	 * @return OperationResponse
	 */
	public OperationResponse saveCommonData(
			CommonDetailsRequest commonDetailsRequest);

	/**
	 * @param certificateRequest
	 * @return OperationResponse
	 */
	public OperationResponse saveCertificate(
			CertificateRequest certificateRequest);

	/**
	 * @param List
	 *            <skillRequest>
	 * @return OperationResponse
	 */

	OperationResponse saveSkill(List<SkillRequest> skillRequestList);

}