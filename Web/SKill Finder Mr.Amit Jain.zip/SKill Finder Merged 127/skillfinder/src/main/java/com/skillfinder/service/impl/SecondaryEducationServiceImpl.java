/**
 * 
 */
package com.skillfinder.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillfinder.dao.SecondaryEducationDao;
import com.skillfinder.model.SecondaryEducation;
import com.skillfinder.service.SecondaryEducationService;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
@Service
public class SecondaryEducationServiceImpl implements SecondaryEducationService {

	@Autowired
	private SecondaryEducationDao secondaryEducationDao;

	@Transactional
	public DatabaseOperationStatus add(SecondaryEducation education) {
		try {
			secondaryEducationDao.add(education);
		} catch (Exception e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus update(SecondaryEducation education) {
		try {
			secondaryEducationDao.update(education);
		} catch (Exception e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	/*
	 * @Transactional public void delete(int id) {
	 * secondaryEducationDao.delete(id); }
	 */

	@Transactional
	public SecondaryEducation getEducation(int id) {
		try {
			return secondaryEducationDao.getEducation(id);
		} catch (Exception e) {
			return null;
		}
	}

	@Transactional
	public List<SecondaryEducation> getAllEducation() {
		List<SecondaryEducation> secondaryEducationsList = new ArrayList<SecondaryEducation>();

		try {
			secondaryEducationsList = secondaryEducationDao.getAllEducation();
		} catch (Exception e) {
		}
		return secondaryEducationsList;
	}

}
