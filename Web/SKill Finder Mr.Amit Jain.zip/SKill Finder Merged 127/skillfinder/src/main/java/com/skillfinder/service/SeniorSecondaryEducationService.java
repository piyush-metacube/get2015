/**
 * 
 */
package com.skillfinder.service;

import java.util.List;

import com.skillfinder.model.SeniorSecondaryEducation;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
public interface SeniorSecondaryEducationService {
	public DatabaseOperationStatus add(SeniorSecondaryEducation education);

	public DatabaseOperationStatus update(SeniorSecondaryEducation education);

	// public void delete(int id);
	public SeniorSecondaryEducation getEducation(int id);

	public List<SeniorSecondaryEducation> getAllEducation();
}
