package com.skillfinder.communication;

public class WelcomeEmail {

	private Email email;

	public WelcomeEmail() {
		email = new Email();
	}

	public void sendMail(String userEmail) {

	}

}
