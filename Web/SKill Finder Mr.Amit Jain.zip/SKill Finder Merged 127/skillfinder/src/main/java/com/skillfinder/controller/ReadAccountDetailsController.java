package com.skillfinder.controller;

import java.util.List;
import java.util.Map;

import com.skillfinder.model.Achievements;
import com.skillfinder.model.Certificate;
import com.skillfinder.model.CommonData;
import com.skillfinder.model.Education;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;
import com.skillfinder.model.Work;

/**
 * @author Piyush Sharma
 *
 */
public interface ReadAccountDetailsController {

	/**
	 * @param userName
	 * @return List<Work>
	 */
	public List<Work> readWorkExperience(String userName);

	/**
	 * @param userName
	 * @return Education
	 */
	public Education readEducation(String userName);

	/**
	 * @param userName
	 * @return CommonData
	 */
	public CommonData readCommonData(String userName);

	/**
	 * @param userName
	 * @return Map<String, List<User>>
	 */
	public Map<String, List<User>> readEndorsement(String userName);

	/**
	 * @param userName
	 * @return List<Skill>
	 */
	public List<Skill> readSkill(String userName);

	/**
	 * @param userName
	 * @return List<Certificate>
	 */
	public List<Certificate> readCertificate(String userName);

	public List<Achievements> readWorkAchievement(String userName);

	public Map<String, List<Achievements>> readEducationalAchievement(
			String userName);

}