/**
 * 
 */
package com.skillfinder.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.WorkDao;
import com.skillfinder.model.User;
import com.skillfinder.model.Work;

/**
 * @author priyamvada
 *
 */
@Repository
public class WorkDaoImpl implements WorkDao {

	@Autowired
	private SessionFactory session;

	@Override
	public void add(Work work) {
		session.getCurrentSession().save(work);

	}

	@Override
	public void update(Work work) {
		Criteria criteria = session.openSession().createCriteria(Work.class);
		session.getCurrentSession().update(work);

	}

	@Override
	public void delete(Work work) {
		Criteria criteria = session.openSession().createCriteria(Work.class);
		session.getCurrentSession().delete(work.getId());
	}

	@Override
	public List<Work> getWorkList(User user) {
		Criteria criteria1 = session.getCurrentSession().createCriteria(
				Work.class);
		Criteria criteria2 = criteria1.createCriteria("user");
		criteria2.add(Restrictions.eq("id", user.getId()));
		return (List<Work>) criteria2.list();
	}

}
