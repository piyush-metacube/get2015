/**
 * project skillfinder
 */
package com.skillfinder.dao;

import java.util.List;
import java.util.Map;

import com.skillfinder.model.Achievements;
import com.skillfinder.model.Education;
import com.skillfinder.model.User;
import com.skillfinder.model.Work;

/**
 * DAO Interface for Achievement
 * 
 * @author priyamvada
 * @version %I %G
 *
 */
public interface AchievementDao {
	/**
	 * to add achievement of user
	 * 
	 * @param user
	 *            user whose achievement is to be added
	 * @param achievements
	 *            achievements to be added
	 */
	public void add(List<Achievements> achievementList);

	/**
	 * to add achievement of user
	 * 
	 * @param user
	 *            user whose achievement is to be updated
	 * @param achievements
	 *            achievements to be updated
	 */
	public void update(User user, Achievements achievements);

	/**
	 * @param achievements
	 *            achievement to be deleted
	 */
	public void delete(Achievements achievements);

	/**
	 * @param achievements
	 *            to get a particular achievement of a user
	 * @return required achievement
	 */
	
	public Achievements getAchievements(Achievements achievements);
	public Map<String,List<Achievements>> getAchievements(Education education);
	
	public List<Achievements> getAchievements(Work work);
	

}
