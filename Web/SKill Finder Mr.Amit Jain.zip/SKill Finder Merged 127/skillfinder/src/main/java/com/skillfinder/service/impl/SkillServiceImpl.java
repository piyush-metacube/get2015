/**
 * 
 */
package com.skillfinder.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillfinder.dao.SkillDao;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;
import com.skillfinder.service.SkillService;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author avinash
 *
 */
@Service
public class SkillServiceImpl implements SkillService {

	@Autowired
	private SkillDao skillDao;

	@Transactional
	public DatabaseOperationStatus add(Skill skill) {
		try {
			if (!skillDao.checkSkill(skill)) {
				skillDao.add(skill);
			} else {
				return DatabaseOperationStatus.FAILURE;
			}
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus update(User user, Skill skill) {
		try {
			skillDao.update(user, skill);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus delete(Skill skill) {
		try {
			skillDao.delete(skill);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public List<Skill> getSkill(User user) {
		List<Skill> skillsList = new ArrayList<Skill>();
		try {
			skillsList = skillDao.getSkill(user);
		} catch (HibernateException e) {
		}
		return skillsList;
	}

	@Transactional
	public boolean checkSkill(Skill skill) {
		try {
			return skillDao.checkSkill(skill);
		} catch (HibernateException e) {
			return false;
		}
	}

	@Override
	public List<User> search(String inputString) {
		return skillDao.search(inputString);
	}

}
