/**
 * 
 */
package com.skillfinder.service;

import java.util.List;
import java.util.Map;

import com.skillfinder.model.Endorsement;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author avinash
 *
 */
public interface EndorsementService {
	public DatabaseOperationStatus add(User user, User endorsedUser, Skill skill);

	public DatabaseOperationStatus delete(int id);

	public Endorsement getEndorsement(int id);

	public Map<String, List<User>> getAllEndorsement(User user);

	public boolean checkEndorsement(Endorsement endorsement);
	
	public int getSkillEndorseMentCount(User user, Skill skill) ;
}
