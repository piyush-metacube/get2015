/**
 * project skill finder
 */
package com.skillfinder.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;

/**
 * Class to store Certificates of respective User
 * 
 * @author Priyamvada
 *
 */
@Entity
@Data

public class Certificate {
	@Id
	@Column(name = "certificate_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name = "certification_date")
	private String certificationDate;
	@Column(name = "headline")
	private String headline;

	@Column
	private String description;

	@Column(name = "logo_url")
	private String certificateLogoUrl;

	@ManyToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "user_id")
	private User user;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCertificationDate() {
		return certificationDate;
	}

	public void setCertificationDate(String certificationDate) {
		this.certificationDate = certificationDate;
	}

	public String getHeadline() {
		return headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCertificateLogoUrl() {
		return certificateLogoUrl;
	}

	public void setCertificateLogoUrl(String certificateLogoUrl) {
		this.certificateLogoUrl = certificateLogoUrl;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((certificateLogoUrl == null) ? 0 : certificateLogoUrl
						.hashCode());
		result = prime
				* result
				+ ((certificationDate == null) ? 0 : certificationDate
						.hashCode());
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result
				+ ((headline == null) ? 0 : headline.hashCode());
		result = prime * result + id;
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Certificate other = (Certificate) obj;
		if (certificateLogoUrl == null) {
			if (other.certificateLogoUrl != null)
				return false;
		} else if (!certificateLogoUrl.equals(other.certificateLogoUrl))
			return false;
		if (certificationDate == null) {
			if (other.certificationDate != null)
				return false;
		} else if (!certificationDate.equals(other.certificationDate))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (headline == null) {
			if (other.headline != null)
				return false;
		} else if (!headline.equals(other.headline))
			return false;
		if (id != other.id)
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

}
