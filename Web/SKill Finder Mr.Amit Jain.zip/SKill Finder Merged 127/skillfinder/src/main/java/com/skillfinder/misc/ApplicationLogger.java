/**
 * 
 */
package com.skillfinder.misc;

import org.apache.log4j.Logger;
import com.skillfinder.controlBox.ApplicationLoggingConfiguration;

/**
 * @author Piyush
 *
 */
public class ApplicationLogger {
	static org.apache.log4j.Logger log = org.apache.log4j.Logger
			.getLogger(ApplicationLogger.class.getName());

	public static void log(String logString) {
		if (ApplicationLoggingConfiguration.releaseLogging) {
			log.info(logString);
		}
	}

	public static void DebugLog(String logString) {
		if (ApplicationLoggingConfiguration.debugLogging) {
			log.debug(logString);
		}
	}

}
