package com.skillfinder.utils;

public enum DatabaseOperationStatus {
SUCCESS,FAILURE
}
