/**
 * 
 */
package com.skillfinder.service;

import java.util.List;

import com.skillfinder.model.User;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
public interface UserService {
	public DatabaseOperationStatus saveCredentials(User user);

	public DatabaseOperationStatus update(User user);

	public DatabaseOperationStatus delete(User user);

	public User getUser(User user);

	public User getUser(int userId);

	public List<User> getAllUser();

	public boolean checkLogin(User user);

	public boolean checkUserExistence(User user);
	
	public List<User> search(String inputString);
}
