package com.skillfinder.exceptions;

public class SkillFinderException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
