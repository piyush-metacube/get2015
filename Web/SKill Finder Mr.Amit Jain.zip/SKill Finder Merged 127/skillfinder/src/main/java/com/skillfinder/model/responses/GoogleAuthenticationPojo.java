package com.skillfinder.model.responses;

public class GoogleAuthenticationPojo {

	private String email;

	private String family_name;

	private String given_name;

	private String id;

	private boolean verified_email;

	public String getEmail() {
		return email;
	}

	public String getFamily_name() {
		return family_name;
	}

	public String getGiven_name() {
		return given_name;
	}

	public String getId() {
		return id;
	}

	public boolean isVerified_email() {
		return verified_email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setFamily_name(String family_name) {
		this.family_name = family_name;
	}

	public void setGiven_name(String given_name) {
		this.given_name = given_name;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setVerified_email(boolean verified_email) {
		this.verified_email = verified_email;
	}

	@Override
	public String toString() {
		return "GooglePojo [id=" + id + ", email=" + email
				+ ", verified_email=" + verified_email + ", given_name="
				+ given_name + ", family_name=" + family_name + "]";
	}

}
