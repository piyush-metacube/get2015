/**
 * 
 */
package com.skillfinder.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.skillfinder.controller.AuthenticationController;
import com.skillfinder.model.requests.UserCredential;
import com.skillfinder.model.responses.GoogleAuthenticationPojo;
import com.skillfinder.model.responses.LoginResponse;
import com.skillfinder.model.responses.OperationResponse;
import com.skillfinder.operations.AuthenticationOperation;
import com.skillfinder.service.UserService;

/**
 * 
 * @author Piyush Sharma
 *
 */
@RestController
@RequestMapping("/accounts")
public class AuthenticationControllerImpl implements AuthenticationController {

	@Autowired
	private AuthenticationOperation authenticationOperation;

	@Autowired
	private UserService userService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.AuthenticationController#checkUserExitence
	 * (java.lang.String)
	 */
	@Override
	@RequestMapping(value = "/isUserExists/{username}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody OperationResponse checkUserExitence(
			@PathVariable("username") String userName) {

		OperationResponse existenceResponse = authenticationOperation
				.checkUserExistence(userName);
		return existenceResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.AuthenticationController#forgotPassword
	 * (java.lang.String)
	 */
	@Override
	@RequestMapping(value = "/reset/{username}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody OperationResponse forgotPassword(
			@PathVariable("username") String userName) {

		OperationResponse resetPasswordResponse = authenticationOperation
				.forgotPassword(userName);
		return resetPasswordResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.controller.impl.AuthenticationController#login(com.
	 * skillfinder.model.requests.UserCredential)
	 */
	@Override
	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public @ResponseBody LoginResponse login(
			@RequestBody UserCredential loginRequest) {

		LoginResponse loginresponse = authenticationOperation
				.login(loginRequest);

		return loginresponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.AuthenticationController#googleOauthLogin
	 * (com.skillfinder.model.responses.GoogleAuthenticationPojo)
	 */
	@Override
	@RequestMapping(value = "/authenticate/google", method = RequestMethod.POST)
	public @ResponseBody LoginResponse googleOauthLogin(
			@RequestBody GoogleAuthenticationPojo googleAuthenticationPojo) {
		LoginResponse googleOauthLoginResponse = authenticationOperation
				.googleLogin(googleAuthenticationPojo);
		return googleOauthLoginResponse;
	}
}
