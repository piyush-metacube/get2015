package com.skillfinder.operations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.skillfinder.communication.PasswordResetEmail;
import com.skillfinder.exceptions.EmailSendingFailedException;
import com.skillfinder.misc.ApplicationLogger;
import com.skillfinder.model.User;
import com.skillfinder.model.requests.UserCredential;
import com.skillfinder.model.responses.GoogleAuthenticationPojo;
import com.skillfinder.model.responses.LoginResponse;
import com.skillfinder.model.responses.OperationResponse;
import com.skillfinder.responsecodes.NegativeResponseCodes;
import com.skillfinder.responsecodes.PositiveResponseCode;
import com.skillfinder.service.UserService;

@Repository
public class AuthenticationOperationImpl implements AuthenticationOperation {

	@Autowired
	private UserService userService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.operations.AuthenticationOperation#checkUserExistence
	 * (java.lang.String)
	 */
	@Override
	public OperationResponse checkUserExistence(String userName) {
		OperationResponse existenceResponse = new OperationResponse();
		if (!userName.isEmpty()) {
			User user = new User();
			user.setUserName(userName);

			if (userService.checkUserExistence(user)) {
				/* User found in database */
				existenceResponse.setStatus(PositiveResponseCode.SF4011.name());
			} else {
				/* User not found in database */
				existenceResponse.setStatus(NegativeResponseCodes.SF400.name());
			}
		} else {
			/* empty Username */
			existenceResponse.setStatus(NegativeResponseCodes.SF401.name());
		}
		return existenceResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.operations.AuthenticationOperation#forgotPassword(java
	 * .lang.String)
	 */
	@Override
	public OperationResponse forgotPassword(String userName) {

		OperationResponse resetPassword = new OperationResponse();

		if (!userName.isEmpty()) {
			User user = new User();
			user.setUserName(userName);

			if (userService.checkUserExistence(user)) {
				PasswordResetEmail passwordResetEmail = new PasswordResetEmail();
				passwordResetEmail.setUserEmail(userName);

				try {
					passwordResetEmail.send();
					resetPassword.setMessage("Reset Password Email Sent");
					/* Reset Password Email Sent */
					resetPassword.setStatus(PositiveResponseCode.SF4031.name());
				} catch (EmailSendingFailedException e) {
					/* Reset Password Email Not Sent */
					resetPassword.setStatus(NegativeResponseCodes.SF403.name());
					if (com.skillfinder.controlBox.ApplicationLoggingConfiguration.debugLogging) {
						ApplicationLogger.log(e.getMessage());
					}
				}
			} else {
				/* user not found */
				resetPassword.setStatus(NegativeResponseCodes.SF400.name());
			}
		} else {
			/* empty username */
			resetPassword.setStatus(NegativeResponseCodes.SF401.name());
		}
		return resetPassword;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.operations.AuthenticationOperation#login(com.skillfinder
	 * .model.requests.UserCredential)
	 */
	@Override
	public LoginResponse login(UserCredential loginRequest) {

		String usernameString = loginRequest.getEmail();
		String passwordString = loginRequest.getPassword();

		LoginResponse loginresponse = new LoginResponse();

		if (!usernameString.isEmpty() && !passwordString.isEmpty()) {
			User user = new User();
			user.setUserName(usernameString);
			user.setPassword(passwordString.hashCode());

			boolean loginCredentialCheck = userService.checkLogin(user);

			if (loginCredentialCheck) {
				/* UserCredential Valid User found */
				loginresponse.setStatus(PositiveResponseCode.SF4011.name());
				return loginresponse;
			}
		}
		/* Invalid Credentials */
		loginresponse.setStatus(NegativeResponseCodes.SF402.name());
		return loginresponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.operations.AuthenticationOperation#googleLogin(com.
	 * skillfinder.model.responses.GoogleAuthenticationPojo)
	 */
	@Override
	public LoginResponse googleLogin(GoogleAuthenticationPojo loginRequest) {

		LoginResponse loginResponse = new LoginResponse();
		String username = loginRequest.getEmail();

		User user = new User();
		user.setUserName(username);

		if (userService.checkUserExistence(user)) {

			boolean loginCredentialCheck = userService.checkLogin(user);

			if (loginCredentialCheck) {
				/* user Found in database */
				loginResponse.setStatus(PositiveResponseCode.SF4011.toString());
				return loginResponse;
			} else {
				/* Invalid Credentials */
				loginResponse.setStatus(NegativeResponseCodes.SF402.toString());
			}
		} else {
			/* First Time user-setup profile */
			loginResponse.setStatus("OK"); /* First Time user-setup profile */
			loginResponse.setStatus(NegativeResponseCodes.SF501.toString());
		}
		return loginResponse;
	}

}
