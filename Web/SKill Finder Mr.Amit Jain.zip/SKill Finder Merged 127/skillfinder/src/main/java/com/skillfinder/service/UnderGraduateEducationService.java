/**
 * 
 */
package com.skillfinder.service;

import java.util.List;

import com.skillfinder.model.UnderGraduateEducation;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
public interface UnderGraduateEducationService {
	public DatabaseOperationStatus add(UnderGraduateEducation education );
	public DatabaseOperationStatus update(UnderGraduateEducation education );
	//public void delete(int id);
	public UnderGraduateEducation getEducation(int id);
	public List<UnderGraduateEducation> getAllEducation();
}
