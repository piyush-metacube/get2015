/**
 * 
 */
package com.skillfinder.responsecodes;

/**
 * @author Piyush SF400 : UserNotfound SF401 : Failed to send password reset
 *         mail
 */
public enum NegativeResponseCodes {
	SF400, SF401, SF402, SF403, SF501, SF602, SF603, SF604, SF605

}
