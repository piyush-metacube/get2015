/**
 * 
 */
package com.skillfinder.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.CommonDataDao;
import com.skillfinder.model.Certificate;
import com.skillfinder.model.CommonData;
import com.skillfinder.model.Education;
import com.skillfinder.model.User;

/**
 * @author priyamvada
 *
 */
@Repository
public class CommonDataDaoImpl implements CommonDataDao {

	@Autowired
	private SessionFactory session;

	@Override
	public void add(User user, CommonData data) {
		session.getCurrentSession().save(data);
	}

	@Override
	public void update(User user, CommonData data) {
		session.getCurrentSession().update(data);
	}

	@Override
	public void delete(CommonData commonData) {
		session.getCurrentSession().delete(getCommonData(commonData));

	}

	@Override
	public CommonData getCommonData(User user) {
		return  get(user.getId());
	}

	@Override
	public CommonData get(int userId) {
		Criteria criteria1 = session.getCurrentSession().createCriteria(
				CommonData.class);
		Criteria criteria2 = criteria1.createCriteria("user");
		criteria2.add(Restrictions.eq("id", userId));
		return ((CommonData) criteria2.uniqueResult());
	}

	@Override
	public CommonData getCommonData(CommonData commonData) {
		return (CommonData) session.getCurrentSession().get(CommonData.class,
				commonData.getId());
	}
}
