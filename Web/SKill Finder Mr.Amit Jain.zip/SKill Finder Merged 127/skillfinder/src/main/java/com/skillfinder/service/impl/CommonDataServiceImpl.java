/**
 * 
 */
package com.skillfinder.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillfinder.dao.CommonDataDao;
import com.skillfinder.model.Certificate;
import com.skillfinder.model.CommonData;
import com.skillfinder.model.User;
import com.skillfinder.service.CommonDataService;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
@Service
public class CommonDataServiceImpl implements CommonDataService {

	@Autowired
	private CommonDataDao commonDataDao;

	@Transactional
	public DatabaseOperationStatus add(User user, CommonData data) {
		try {
			commonDataDao.add(user, data);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus update(User user, CommonData data) {
		try {
			commonDataDao.update(user, data);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus delete(CommonData commonData) {
		try {
			commonDataDao.delete(commonData);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public CommonData getCommonData(User user) {
		try {
			return commonDataDao.getCommonData(user);
		} catch (HibernateException e) {
			return null;
		}
	}

	@Transactional
	public CommonData get(int userId) {
		try {
			return commonDataDao.get(userId);
		} catch (HibernateException e) {
			return null;
		}
	}

}
