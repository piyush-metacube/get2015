package com.skillfinder.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.skillfinder.dao.PostGraduationEducationDao;
import com.skillfinder.model.Endorsement;
import com.skillfinder.model.PostGraduateEducation;

@Repository
public class PostGraduationEducationDaoImpl implements PostGraduationEducationDao {

	@Autowired
	private SessionFactory session;
	
	@Override
	public void add(PostGraduateEducation education) {
		session.getCurrentSession().save(education);
		
	}

	@Override
	public void update(PostGraduateEducation education) {
		session.getCurrentSession().update(education);
		
	}

	@Override
	public void delete(int id) {
		session.getCurrentSession().delete(getEducation(id));
		
	}

	@Override
	public PostGraduateEducation getEducation(int id) {
		Criteria cr = session.getCurrentSession().createCriteria(PostGraduateEducation.class);
		return (PostGraduateEducation) cr.list();
	}

	@Override
	public List<PostGraduateEducation> getAllEducation() {
		Criteria criteria = session.getCurrentSession().createCriteria(PostGraduateEducation.class);
		return criteria.list();
	}
}
