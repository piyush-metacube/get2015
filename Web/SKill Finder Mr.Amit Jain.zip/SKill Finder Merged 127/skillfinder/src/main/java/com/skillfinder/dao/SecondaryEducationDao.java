/**
 * 
 */
package com.skillfinder.dao;

import java.util.List;

import com.skillfinder.model.SecondaryEducation;

/**
 * @author jai shree krishna
 *
 */
public interface SecondaryEducationDao {
	public void add(SecondaryEducation education );
	public void update(SecondaryEducation education );
	public void delete(int id);
	public SecondaryEducation getEducation(int id);
	public List<SecondaryEducation> getAllEducation();
}
