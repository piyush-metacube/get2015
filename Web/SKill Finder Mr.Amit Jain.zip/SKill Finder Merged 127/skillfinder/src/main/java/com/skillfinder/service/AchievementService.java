package com.skillfinder.service;

import java.util.List;
import java.util.Map;

import com.skillfinder.model.Achievements;
import com.skillfinder.model.Education;
import com.skillfinder.model.Work;

public interface AchievementService {
	public Map<String, List<Achievements>> getAchievements(Education education);

	public List<Achievements> getAchievements(Work work);
	
	/**
	 * to add achievement of user
	 * 
	 * @param user
	 *            user whose achievement is to be added
	 * @param achievements
	 *            achievements to be added
	 */
	public void add(List<Achievements> achievementList);

}
