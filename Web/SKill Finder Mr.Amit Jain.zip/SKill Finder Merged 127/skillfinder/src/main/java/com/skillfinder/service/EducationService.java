/**
 */
package com.skillfinder.service;

import java.util.List;

import com.skillfinder.model.Education;
import com.skillfinder.model.User;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author avinash
 *
 */
public interface EducationService {
	public DatabaseOperationStatus add(User user, Education education);

	public DatabaseOperationStatus update(Education education);

	public DatabaseOperationStatus delete(Education education);

	public Education getEducation(User user);

}
