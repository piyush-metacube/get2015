package com.skillfinder.operations.crud;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.CommonDataDao;
import com.skillfinder.dao.EndorsementDao;
import com.skillfinder.dao.impl.CommonDataDaoImpl;
import com.skillfinder.dao.impl.EndorsementDaoImpl;
import com.skillfinder.model.Achievements;
import com.skillfinder.model.Certificate;
import com.skillfinder.model.CommonData;
import com.skillfinder.model.Education;
import com.skillfinder.model.PostGraduateEducation;
import com.skillfinder.model.SecondaryEducation;
import com.skillfinder.model.SeniorSecondaryEducation;
import com.skillfinder.model.Skill;
import com.skillfinder.model.UnderGraduateEducation;
import com.skillfinder.model.User;
import com.skillfinder.model.Work;
import com.skillfinder.model.requests.AchievementRequest;
import com.skillfinder.model.requests.CertificateRequest;
import com.skillfinder.model.requests.CommonDetailsRequest;
import com.skillfinder.model.requests.EducationDataRequest;
import com.skillfinder.model.requests.SkillRequest;
import com.skillfinder.model.requests.UserCredential;
import com.skillfinder.model.requests.WorkExperienceRequest;
import com.skillfinder.model.responses.OperationResponse;
import com.skillfinder.responsecodes.NegativeResponseCodes;
import com.skillfinder.responsecodes.PositiveResponseCode;
import com.skillfinder.service.CertificateService;
import com.skillfinder.service.CommonDataService;
import com.skillfinder.service.EducationService;
import com.skillfinder.service.EndorsementService;
import com.skillfinder.service.SkillService;
import com.skillfinder.service.UserService;
import com.skillfinder.service.WorkService;
import com.skillfinder.service.impl.EducationServiceImpl;
import com.skillfinder.service.impl.SkillServiceImpl;
import com.skillfinder.service.impl.UserServiceImpl;
import com.skillfinder.service.impl.WorkServiceImpl;
import com.skillfinder.utils.DatabaseOperationStatus;
import com.skillfinder.utils.DateConversion;
import com.skillfinder.utils.EducationLevel;

@Repository
public class CreateOperation {

	@Autowired
	private UserService userService;
	@Autowired
	private CommonDataService commonDataService;
	@Autowired
	private EducationService educationService;
	@Autowired
	private EndorsementService endorsementService;
	@Autowired
	private SkillService skillService;
	@Autowired
	private WorkService workService;

	@Autowired
	private CertificateService certificateService;

	public OperationResponse saveCredentials(UserCredential userCredentials) {
		User user = new User();
		user.setUserName(userCredentials.getEmail());
		user.setPassword(userCredentials.getPassword().hashCode());

		OperationResponse saveCredentialOperationResponse = new OperationResponse();
		DatabaseOperationStatus dbOperationStatus = userService
				.saveCredentials(user);
		/* User Credentials saved Status : SUCCESS,FAILURE */
		saveCredentialOperationResponse.setStatus(dbOperationStatus.toString());

		return saveCredentialOperationResponse;
	}

	public OperationResponse saveWork(
			WorkExperienceRequest workExperienceRequest) {
		OperationResponse saveWorkOperationResponse = new OperationResponse();

		User user = new User();
		user.setUserName(workExperienceRequest.getUserId());

		Work work = new Work();
		work.setCompanyName(workExperienceRequest.getCompanyName());
		work.setDesignation(workExperienceRequest.getDesignation());
		work.setStartTime(workExperienceRequest.getWorkingFrom());
		work.setEndTime(workExperienceRequest.getWorkingTo());
		work.setUser(user);

		DatabaseOperationStatus dbOperationStatus = workService.add(work);

		/* Work saved status : SUCCESS,FAILURE */
		saveWorkOperationResponse.setStatus(dbOperationStatus.toString());

		return saveWorkOperationResponse;
	}

	public OperationResponse saveEducation(
			EducationDataRequest educationDataRequest) {
		OperationResponse saveEducationOperationResponse = new OperationResponse();

		User user = new User();
		user.setUserName(educationDataRequest.getUserId());

		Education education = new Education();
		education.setUser(user);
		if (educationDataRequest.getLevel().equals(EducationLevel.PG.name())) {
			/* setup PostGraduate Education */
			setupPostGraduateEducation(educationDataRequest, education);
		} else if (educationDataRequest.getLevel().equals(
				EducationLevel.UG.name())) {
			/* setup UnderGraduate Education */
			setupUnderGraduateEducation(educationDataRequest, education);
		} else if (educationDataRequest.getLevel().equals(
				EducationLevel.SE.name())) {
			/* setup Secondary Education */
			setupSecondaryEducation(educationDataRequest, education);
		} else if (educationDataRequest.getLevel().equals(
				EducationLevel.SSE.name())) {
			/* setup Senior Secondary Education */
			setupSeniorSecondaryEducation(educationDataRequest, education);
		}
		DatabaseOperationStatus dbOperationStatus = educationService.add(user,
				education);

		/* Education saved Status SUCCESS,FAILURE */
		saveEducationOperationResponse.setStatus(dbOperationStatus.toString());

		return saveEducationOperationResponse;
	}

	private void setupSecondaryEducation(
			EducationDataRequest educationDataRequest, Education education) {
		SecondaryEducation secondaryEducation = new SecondaryEducation();
		List<Achievements> achievementList = new ArrayList<Achievements>();

		for (AchievementRequest achievementInRequest : educationDataRequest
				.getAchivements()) {
			Achievements achievements = new Achievements();

			achievements.setHeadline(achievementInRequest.getAchivementTitle());
			achievements.setDescription(achievementInRequest
					.getAchivementDescription());
			achievements.setYear(Integer.parseInt(achievementInRequest
					.getAchivementYear()));
			achievementList.add(achievements);
		}

		// secondaryEducation.setAchievements(achievementList);
		// change it to achievement dao serviuce
		secondaryEducation.setSchoolName(educationDataRequest.getCollege());
		secondaryEducation.setYear(educationDataRequest.getYear());
		education.setSecondaryEducation(secondaryEducation);
	}

	private void setupSeniorSecondaryEducation(
			EducationDataRequest educationDataRequest, Education education) {
		SeniorSecondaryEducation seniorSecondaryEducation = new SeniorSecondaryEducation();
		List<Achievements> achievementList = new ArrayList<Achievements>();

		for (AchievementRequest achievementInRequest : educationDataRequest
				.getAchivements()) {
			Achievements achievements = new Achievements();

			achievements.setHeadline(achievementInRequest.getAchivementTitle());
			achievements.setDescription(achievementInRequest
					.getAchivementDescription());
			achievements.setYear(Integer.parseInt(achievementInRequest
					.getAchivementYear()));
			achievementList.add(achievements);
		}

		// seniorSecondaryEducation.setAchievements(achievementList);
		seniorSecondaryEducation.setSchoolName(educationDataRequest
				.getCollege());
		seniorSecondaryEducation.setYear(educationDataRequest.getYear());
		education.setSeniorSecondaryEducation(seniorSecondaryEducation);
	}

	private void setupPostGraduateEducation(
			EducationDataRequest educationDataRequest, Education education) {
		PostGraduateEducation postGraduateEducation = new PostGraduateEducation();
		List<Achievements> achievementList = new ArrayList<Achievements>();

		for (AchievementRequest achievementInRequest : educationDataRequest
				.getAchivements()) {
			Achievements achievements = new Achievements();

			achievements.setHeadline(achievementInRequest.getAchivementTitle());
			achievements.setDescription(achievementInRequest
					.getAchivementDescription());
			achievements.setYear(Integer.parseInt(achievementInRequest
					.getAchivementYear()));
			achievementList.add(achievements);
		}

		// postGraduateEducation.setAchievements(achievementList);
		postGraduateEducation.setCollegeName(educationDataRequest.getCollege());
		postGraduateEducation.setYear(educationDataRequest.getYear());
		education.setPostGraduateEducation(postGraduateEducation);
	}

	private void setupUnderGraduateEducation(
			EducationDataRequest educationDataRequest, Education education) {
		UnderGraduateEducation underGraduateEducation = new UnderGraduateEducation();
		List<Achievements> achievementList = new ArrayList<Achievements>();

		for (AchievementRequest achievementInRequest : educationDataRequest
				.getAchivements()) {
			Achievements achievements = new Achievements();

			achievements.setHeadline(achievementInRequest.getAchivementTitle());
			achievements.setDescription(achievementInRequest
					.getAchivementDescription());
			achievements.setYear(Integer.parseInt(achievementInRequest
					.getAchivementYear()));
			achievementList.add(achievements);
		}

		// underGraduateEducation.setAchievements(achievementList);
		underGraduateEducation
				.setCollegeName(educationDataRequest.getCollege());
		underGraduateEducation.setYear(educationDataRequest.getYear());
		education.setUnderGraduateEducation(underGraduateEducation);
	}

	public OperationResponse saveCommonDetails(
			CommonDetailsRequest commonDetailsRequest) {

		OperationResponse saveCommonDataOperationResponse = new OperationResponse();

		User user = new User();
		user.setUserName(commonDetailsRequest.getEmail());

		CommonData commonData = new CommonData();
		commonData.setCity(commonDetailsRequest.getCity());
		commonData.setCountry(commonDetailsRequest.getCountry());
		commonData.setCoverPicUrl(commonDetailsRequest.getCoverPic());
		commonData.setDateOfBirth(commonDetailsRequest.getDateOfBirth());
		commonData.setEmail(commonDetailsRequest.getEmail());
		commonData.setFacebookURLString(commonDetailsRequest.getFacebook());
		commonData.setFirstName(commonDetailsRequest.getFirstname());
		commonData.setGender(commonDetailsRequest.getGender().charAt(0));
		commonData.setLastName(commonDetailsRequest.getLastName());
		commonData.setLinkedInURLString(commonDetailsRequest.getLinkedin());
		commonData.setPhotoURL(commonDetailsRequest.getProfilePic());
		commonData.setTagLine(commonDetailsRequest.getTagline());
		commonData.setUser(user);

		DatabaseOperationStatus dbOperationStatus = commonDataService.add(user,
				commonData);

		/* Common data saved Status SUCCESS,FAILURE */
		saveCommonDataOperationResponse.setStatus(dbOperationStatus.toString());

		return saveCommonDataOperationResponse;
	}

	public OperationResponse saveSkill(SkillRequest skillRequest) {

		OperationResponse saveSkillOperationResponse = new OperationResponse();

		User user = new User();
		user.setUserName(skillRequest.getEmail());

		Skill skill = new Skill();
		skill.setName(skillRequest.getSkillName());
		skill.setUser(user);

		skill.setUser(user);
		DatabaseOperationStatus dbOperationStatus = skillService.add(skill);

		/* Skill data saved Status SUCCESS,FAILURE */
		saveSkillOperationResponse.setStatus(dbOperationStatus.toString());

		return saveSkillOperationResponse;
	}

	public OperationResponse saveCertificate(
			CertificateRequest certificateRequest) {

		OperationResponse saveCommonDataOperationResponse = new OperationResponse();

		User user = new User();
		user.setUserName(certificateRequest.getEmail());

		Certificate certificate = new Certificate();
		certificate.setHeadline(certificateRequest.getTitle());
		certificate.setDescription(certificateRequest.getDescription());
		certificate.setUser(user);
		certificate.setCertificationDate(certificateRequest.year);

		DatabaseOperationStatus dbOperationStatus = certificateService.add(
				user, certificate);

		/* Certificate data saved Status SUCCESS,FAILURE */
		saveCommonDataOperationResponse.setStatus(dbOperationStatus.toString());

		return saveCommonDataOperationResponse;
	}
}
