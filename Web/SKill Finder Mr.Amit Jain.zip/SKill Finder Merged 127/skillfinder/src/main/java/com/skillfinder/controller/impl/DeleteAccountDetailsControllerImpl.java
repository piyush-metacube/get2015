package com.skillfinder.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.skillfinder.controller.DeleteAccountDetailsController;
import com.skillfinder.model.requests.CertificateRequest;
import com.skillfinder.model.requests.CommonDetailsRequest;
import com.skillfinder.model.requests.EducationDataRequest;
import com.skillfinder.model.requests.SkillRequest;
import com.skillfinder.model.requests.WorkExperienceRequest;
import com.skillfinder.model.responses.OperationResponse;
import com.skillfinder.operations.crud.DeleteOperation;
import com.skillfinder.service.CommonDataService;
import com.skillfinder.service.EducationService;
import com.skillfinder.service.EndorsementService;
import com.skillfinder.service.SkillService;
import com.skillfinder.service.UserService;
import com.skillfinder.service.WorkService;

@RestController
@RequestMapping("/accounts/delete")
public class DeleteAccountDetailsControllerImpl implements
		DeleteAccountDetailsController {

	@Autowired
	private DeleteOperation deleteOperation;
	@Autowired
	private UserService userService;
	@Autowired
	private CommonDataService commonDataService;
	@Autowired
	private EducationService educationService;
	@Autowired
	private EndorsementService endorsementService;
	@Autowired
	private SkillService skillService;
	@Autowired
	private WorkService workService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.controller.impl.DeleteAccountDetailsController#
	 * deleteWorkExperience
	 * (com.skillfinder.model.requests.WorkExperienceRequest)
	 */
	@Override
	@RequestMapping(value = "/work", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse deleteWorkExperience(
			@RequestBody WorkExperienceRequest workExperienceRequest) {
		OperationResponse OperationResponse = deleteOperation
				.deleteWork(workExperienceRequest);
		return OperationResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.controller.impl.DeleteAccountDetailsController#
	 * deleteEducation(com.skillfinder.model.requests.EducationDataRequest)
	 */
	@Override
	@RequestMapping(value = "/education", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse deleteEducation(
			@RequestBody EducationDataRequest educationDataRequest) {
		OperationResponse OperationResponse = deleteOperation
				.deleteEducation(educationDataRequest);
		return OperationResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.controller.impl.DeleteAccountDetailsController#
	 * deleteCommonData(com.skillfinder.model.requests.CommonDetailsRequest)
	 */
	@Override
	@RequestMapping(value = "/commondata", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse deleteCommonData(
			@RequestBody CommonDetailsRequest commonDetailsRequest) {
		OperationResponse OperationResponse = deleteOperation
				.deleteCommonDetails(commonDetailsRequest);
		return OperationResponse;
	}

	@Override
	@RequestMapping(value = "/skill", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse deleteSkill(
			@RequestBody SkillRequest skillRequest) {
		OperationResponse OperationResponse = deleteOperation
				.deleteSkill(skillRequest);
		return OperationResponse;
	}

	@Override
	@RequestMapping(value = "/certificate", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse deleteCertificate(
			@RequestBody CertificateRequest certificateRequest) {
		OperationResponse OperationResponse = deleteOperation
				.deleteCertificate(certificateRequest);
		return OperationResponse;
	}
}