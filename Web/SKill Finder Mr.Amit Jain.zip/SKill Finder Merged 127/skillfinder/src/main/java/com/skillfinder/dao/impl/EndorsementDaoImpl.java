/**
 * 
 */
package com.skillfinder.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.EndorsementDao;
import com.skillfinder.model.Endorsement;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;

/**
 * @author priyamvada
 *
 */
@Repository
public class EndorsementDaoImpl implements EndorsementDao {

	@Autowired
	private SessionFactory session;

	@Override
	public boolean add(Endorsement endorsement) {
		if (session.getCurrentSession() == null) {
			session.openSession().save(endorsement);
		} else {
			session.getCurrentSession().save(endorsement);
		}
		return true;
	}

	@Override
	public void delete(int id) {
		session.getCurrentSession().delete(getEndorsement(id));
	}

	@Override
	public Endorsement getEndorsement(int id) {
		return (Endorsement) session.getCurrentSession().get(Endorsement.class,
				id);
	}

	@Override
	public Map<String, List<User>> getAllEndorsement(List<Skill> skillList) {
		Map<String, List<User>> userIdMap = new HashMap<String, List<User>>();
		for (Skill skill : skillList) {
			String hql = "SELECT endorsedUserId FROM Endorsement where skillId = "
					+ skill.getId();
			org.hibernate.Query query = session.getCurrentSession()
					.createQuery(hql);
			List<Integer> endorsedUserId = query.list();
			UserDaoImpl userDaoImpl = new UserDaoImpl();
			List<User> userList = new ArrayList<User>();
			for(int userId : endorsedUserId) {
				User user = userDaoImpl.getUser(userId);
				userList.add(user);
			}
			userIdMap.put(skill.getName(), userList);
		}
		System.out.println(userIdMap);
		return userIdMap;
	}

	@Override
	public boolean checkEndorsement(Endorsement endorsement) {
		String hql = "FROM Endorsement where skillId = "
				+ endorsement.getSkillId() + " and userId = "
				+ endorsement.getUserId() + " and endorsedUserId = "
				+ endorsement.getEndorsedUserId();
		org.hibernate.Query query = session.getCurrentSession()
				.createQuery(hql);
		Endorsement resultEndorsement = (Endorsement) query.uniqueResult();
		if (resultEndorsement == null) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int getSkillEndorseMentCount(User user, Skill skill) {
		return ((Long) session
				.getCurrentSession()
				.createQuery(
						"select count(*) from Endorsement where skillId = "
								+ skill.getId() + "and userId = "
								+ user.getId()).uniqueResult()).intValue();
	}
}
