package com.skillfinder.communication;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.skillfinder.exceptions.EmailSendingFailedException;

public class Email {
	private String host = "smtp.gmail.com";
	private String port = "465";
	private String senderEmailAddress = "piyush.sharma@metacube.com";
	private String recieverEmailAddress = "piyush.sharma@outlook.in";
	private String senderEmailPassword = "ystqrspgzqfedtxr";
	private String emailBody = "";
	private String subject = "Reset SkillFinder Account Password";

	public void setRecieverEmailAddress(String recieverEmailAddress) {
		this.recieverEmailAddress = recieverEmailAddress;
	}

	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public void sendMail() throws EmailSendingFailedException {

		Properties props = new Properties();
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.socketFactory.port", port);
		props.put("mail.smtp.socketFactory.class",
				"javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", port);

		props.put("mail.smtp.socketFactory.fallback", "false");
		props.put("mail.smtp.starttls.enable", "true");

		Session session = Session.getDefaultInstance(props,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(senderEmailAddress,
								senderEmailPassword);
					}
				});
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(senderEmailAddress));
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(recieverEmailAddress));
			message.setSubject(subject);
			message.setText(emailBody);

			Transport.send(message);
		} catch (MessagingException e) {
			throw new EmailSendingFailedException();
		}
	}
}
