/**
 * 
 */
package com.skillfinder.dao;

import java.util.List;

import com.skillfinder.model.User;

/**
 * @author priyamvada
 *
 */
public interface UserDao {
	public boolean saveCredentials(User user);

	public void update(User user);

	public void delete(User user);

	public User getUser(User user);

	public User getUser(int userId);

	public List<User> getAllUser();

	public boolean checkLogin(User user);
	
	public boolean checkUserExistence(User user);
	
	public List<User> search(String inputString);

}
