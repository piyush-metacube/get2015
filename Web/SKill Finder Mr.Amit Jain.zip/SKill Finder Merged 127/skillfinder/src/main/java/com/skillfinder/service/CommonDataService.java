/**
 * 
 */
package com.skillfinder.service;

import java.util.List;

import com.skillfinder.model.CommonData;
import com.skillfinder.model.User;
import com.skillfinder.model.responses.OperationResponse;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author avinash
 */
public interface CommonDataService {
	public DatabaseOperationStatus add(User user, CommonData commonData);

	public DatabaseOperationStatus update(User user, CommonData commonData);

	public DatabaseOperationStatus delete(CommonData commonData);
	
	public CommonData get(int userId);

	public CommonData getCommonData(User user);

}
