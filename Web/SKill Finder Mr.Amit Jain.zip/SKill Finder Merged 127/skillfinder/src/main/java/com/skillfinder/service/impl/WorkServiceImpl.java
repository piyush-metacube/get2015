/**
 * 
 */
package com.skillfinder.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillfinder.dao.WorkDao;
import com.skillfinder.model.Certificate;
import com.skillfinder.model.User;
import com.skillfinder.model.Work;
import com.skillfinder.service.WorkService;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
@Service
public class WorkServiceImpl implements WorkService {

	@Autowired
	private WorkDao workDao;

	@Transactional
	public DatabaseOperationStatus add(Work work) {
		try {
			workDao.add(work);
		} catch (Exception e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus update(Work work) {
		try {
			workDao.update(work);
		} catch (Exception e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus delete(Work work) {
		try {
			workDao.delete(work);
		} catch (Exception e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Override
	public List<Work> getWorkList(User user) {
		List<Work> listOfCertificates = new ArrayList<Work>();
		try {
			listOfCertificates = workDao.getWorkList(user);
		} catch (Exception e) {
			
		}
		return listOfCertificates;
	}
}
