/**
 * 
 */
package com.skillfinder.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillfinder.dao.CertificateDao;
import com.skillfinder.model.Certificate;
import com.skillfinder.model.Education;
import com.skillfinder.model.User;
import com.skillfinder.service.CertificateService;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author priyamvada
 *
 */
@Service
public class CertificateServiceImpl implements CertificateService {

	@Autowired
	private CertificateDao certificateDao;

	@Transactional
	public DatabaseOperationStatus add(User user, Certificate certificate) {

		try {
			certificateDao.add(user, certificate);
		} catch (HibernateException e) {

			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus update(User user, Certificate certificate) {
		try {
			certificateDao.update(user, certificate);
		} catch (Exception e) {

			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus delete(Certificate certificate) {
		try {
			certificateDao.delete(certificate);
		} catch (Exception e) {

			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public Certificate getCertificate(Certificate certificate) {
		try {
			return certificateDao.getCertificate(certificate);
		} catch (HibernateException e) {
			return null;
		}
	}

	@Transactional
	public List<Certificate> getCertificateList(User user) {
		List<Certificate> listOfCertificates = new ArrayList<Certificate>();
		try {
			listOfCertificates = certificateDao.getCertificateList(user);
		} catch (HibernateException e) {
		}
		return listOfCertificates;
	}
}
