/**
 * 
 */
package com.skillfinder.dao;

import java.util.List;

import com.skillfinder.model.User;
import com.skillfinder.model.Work;

/**
 * @author jai shree krishna
 *
 */
public interface WorkDao {
	public void add(Work work);

	public void update(Work work);

	public void delete(Work work);

	public List<Work> getWorkList(User user);
}
