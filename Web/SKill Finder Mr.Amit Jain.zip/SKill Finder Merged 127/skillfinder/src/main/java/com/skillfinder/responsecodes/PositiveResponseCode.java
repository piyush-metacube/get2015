package com.skillfinder.responsecodes;

public enum PositiveResponseCode {
	SF4011, SF4031, SF6021, SF6031, SF6041, SF6051, SUCCESS
}
