/**
 * 
 */
package com.skillfinder.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

/**
 * Class to store Endorsement of respective User
 * 
 * @author Priyamvada
 *
 */

@Entity
@Table(name = "Endorsement")
@Data
public class Endorsement {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int endorsedId;
	@Column(name = "skill_id")
	private int skillId;

	@Column(name = "endorsed_user_id")
	private int endorsedUserId;

	@Column(name = "user_id")
	private int userId;

	public int getEndorsedId() {
		return endorsedId;
	}

	public void setEndorsedId(int endorsedId) {
		this.endorsedId = endorsedId;
	}

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public int getEndorsedUserId() {
		return endorsedUserId;
	}

	public void setEndorsedUserId(int endorcedUserId) {
		this.endorsedUserId = endorcedUserId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
}
