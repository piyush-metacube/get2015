/**
 * 
 */
package com.skillfinder.controller.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.skillfinder.controller.SaveAccountDetailsController;
import com.skillfinder.model.Certificate;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;
import com.skillfinder.model.requests.CertificateRequest;
import com.skillfinder.model.requests.CommonDetailsRequest;
import com.skillfinder.model.requests.EducationDataRequest;
import com.skillfinder.model.requests.SkillRequest;
import com.skillfinder.model.requests.UserCredential;
import com.skillfinder.model.requests.WorkExperienceRequest;
import com.skillfinder.model.responses.OperationResponse;
import com.skillfinder.operations.crud.CreateOperation;
import com.skillfinder.service.CertificateService;
import com.skillfinder.service.CommonDataService;
import com.skillfinder.service.EducationService;
import com.skillfinder.service.EndorsementService;
import com.skillfinder.service.SkillService;
import com.skillfinder.service.UserService;
import com.skillfinder.service.WorkService;

/**
 * @author Piyush
 *
 */

@RestController
@RequestMapping("/accounts/save")
public class SaveAccountDetailsControllerImpl implements
		SaveAccountDetailsController {

	@Autowired
	private CreateOperation createOperation;
	@Autowired
	private UserService userService;
	@Autowired
	private CommonDataService commonDataService;
	@Autowired
	private EducationService educationService;
	@Autowired
	private EndorsementService endorsementService;
	@Autowired
	private SkillService skillService;
	@Autowired
	private WorkService workService;
	@Autowired
	private CertificateService certificateService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.SaveAccountDetailsController#saveCredentials
	 * (com.skillfinder.model.requests.UserCredential)
	 */

	@Override
	@RequestMapping(value = "/usercredentials", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse saveCredentials(
			@RequestBody UserCredential userCredential) {
		OperationResponse operationResponse = createOperation
				.saveCredentials(userCredential);
		return operationResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.controller.impl.SaveAccountDetailsController#
	 * saveWorkExperience(com.skillfinder.model.requests.WorkExperienceRequest)
	 */

	@Override
	@RequestMapping(value = "/work", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse saveWorkExperience(
			@RequestBody WorkExperienceRequest workExperienceRequest) {
		OperationResponse OperationResponse = createOperation
				.saveWork(workExperienceRequest);
		return OperationResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.SaveAccountDetailsController#saveEducation
	 * (com.skillfinder.model.requests.EducationDataRequest)
	 */

	@Override
	@RequestMapping(value = "/education", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse saveEducation(
			@RequestBody EducationDataRequest educationDataRequest) {

		OperationResponse OperationResponse = createOperation
				.saveEducation(educationDataRequest);

		return OperationResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.SaveAccountDetailsController#saveCommonData
	 * (com.skillfinder.model.requests.CommonDetailsRequest)
	 */

	@Override
	@RequestMapping(value = "/commondata", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse saveCommonData(
			@RequestBody CommonDetailsRequest commonDetailsRequest) {
		OperationResponse OperationResponse = createOperation
				.saveCommonDetails(commonDetailsRequest);
		return OperationResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.SaveAccountDetailsController#saveCertificate
	 * (com.skillfinder.model.requests.CertificateRequest)
	 */
	@Override
	@RequestMapping(value = "/certificate", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse saveCertificate(
			@RequestBody CertificateRequest certificateRequest) {

		OperationResponse OperationResponse = createOperation
				.saveCertificate(certificateRequest);

		return OperationResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.SaveAccountDetailsController#saveSkill
	 * (com.skillfinder.model.requests.SkillRequest)
	 */
	@Override
	@RequestMapping(value = "/skill", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse saveSkill(
			@RequestBody List<SkillRequest> skillRequestList) {
		OperationResponse operationResponse = null;
		for (SkillRequest skillRequest : skillRequestList) {
			operationResponse = createOperation.saveSkill(skillRequest);
		}
		return operationResponse;
	}
}
