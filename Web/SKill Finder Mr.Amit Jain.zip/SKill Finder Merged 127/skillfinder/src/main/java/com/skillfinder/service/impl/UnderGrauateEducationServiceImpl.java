package com.skillfinder.service.impl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.skillfinder.dao.UnderGraduateEducationDao;
import com.skillfinder.model.UnderGraduateEducation;
import com.skillfinder.service.UnderGraduateEducationService;
import com.skillfinder.utils.DatabaseOperationStatus;

@Service
public class UnderGrauateEducationServiceImpl implements
		UnderGraduateEducationService {

	@Autowired
	private UnderGraduateEducationDao educationDao;

	@Transactional
	public DatabaseOperationStatus add(UnderGraduateEducation education) {
		try {
			educationDao.add(education);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus update(UnderGraduateEducation education) {
		try {
			educationDao.update(education);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public UnderGraduateEducation getEducation(int id) {
		try {
			return educationDao.getEducation(id);
		} catch (HibernateException e) {
			return null;
		}
	}

	@Transactional
	public List<UnderGraduateEducation> getAllEducation() {
		List<UnderGraduateEducation> underGraduateEducationsList = new ArrayList<UnderGraduateEducation>();
		try {
			underGraduateEducationsList = educationDao.getAllEducation();
		} catch (HibernateException e) {
			return underGraduateEducationsList;
		}
		return underGraduateEducationsList;
	}

}
