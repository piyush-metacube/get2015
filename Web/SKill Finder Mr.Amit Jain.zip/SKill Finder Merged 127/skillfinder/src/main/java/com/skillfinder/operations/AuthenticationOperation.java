package com.skillfinder.operations;

import com.skillfinder.model.requests.UserCredential;
import com.skillfinder.model.responses.GoogleAuthenticationPojo;
import com.skillfinder.model.responses.LoginResponse;
import com.skillfinder.model.responses.OperationResponse;

public interface AuthenticationOperation {

	public OperationResponse checkUserExistence(String userName);

	public OperationResponse forgotPassword(String userName);

	public LoginResponse login(UserCredential loginRequest);

	public LoginResponse googleLogin(GoogleAuthenticationPojo loginRequest);

}