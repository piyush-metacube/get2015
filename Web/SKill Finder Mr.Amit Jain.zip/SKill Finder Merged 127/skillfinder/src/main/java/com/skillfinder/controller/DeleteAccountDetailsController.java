package com.skillfinder.controller;

import com.skillfinder.model.requests.CertificateRequest;
import com.skillfinder.model.requests.CommonDetailsRequest;
import com.skillfinder.model.requests.EducationDataRequest;
import com.skillfinder.model.requests.SkillRequest;
import com.skillfinder.model.requests.WorkExperienceRequest;
import com.skillfinder.model.responses.OperationResponse;

/**
 * @author Piyush Sharma
 *
 */
public interface DeleteAccountDetailsController {

	/**
	 * @param workExperienceRequest
	 * @return OperationResponse
	 */
	public OperationResponse deleteWorkExperience(
			WorkExperienceRequest workExperienceRequest);

	/**
	 * @param educationDataRequest
	 * @return OperationResponse
	 */
	public OperationResponse deleteEducation(
			EducationDataRequest educationDataRequest);

	/**
	 * @param commonDetailsRequest
	 * @return OperationResponse
	 */
	public OperationResponse deleteCommonData(
			CommonDetailsRequest commonDetailsRequest);

	/**
	 * @param skillRequest
	 * @return
	 */
	public OperationResponse deleteSkill(SkillRequest skillRequest);

	/**
	 * @param certificateRequest
	 * @return
	 */
	public OperationResponse deleteCertificate(
			CertificateRequest certificateRequest);

}