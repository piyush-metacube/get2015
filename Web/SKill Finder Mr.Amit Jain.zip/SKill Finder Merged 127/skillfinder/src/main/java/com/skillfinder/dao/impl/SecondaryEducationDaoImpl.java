/**
 * 
 */
package com.skillfinder.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.SecondaryEducationDao;
import com.skillfinder.model.SecondaryEducation;

/**
 * @author jai shree krishna
 *
 */
@Repository
public class SecondaryEducationDaoImpl implements SecondaryEducationDao {

	@Autowired
	private SessionFactory session;

	@Override
	public void add(SecondaryEducation education) {
		session.getCurrentSession().save(education);
	}

	@Override
	public void update(SecondaryEducation education) {
		session.getCurrentSession().update(education);
	}

	@Override
	public void delete(int id) {
		session.getCurrentSession().delete(getEducation(id));
	}

	@Override
	public SecondaryEducation getEducation(int id) {
		Criteria cr = session.getCurrentSession().createCriteria(
				SecondaryEducation.class);
		return (SecondaryEducation) cr.list();
	}

	@Override
	public List<SecondaryEducation> getAllEducation() {
		Criteria cr = session.getCurrentSession().createCriteria(
				SecondaryEducation.class);
		return cr.list();
	}

}
