/**
 * 
 */
package com.skillfinder.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillfinder.dao.EndorsementDao;
import com.skillfinder.dao.SkillDao;
import com.skillfinder.dao.UserDao;
import com.skillfinder.model.Endorsement;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;
import com.skillfinder.service.EndorsementService;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
@Service
public class EndorsementServiceImpl implements EndorsementService {

	@Autowired
	private EndorsementDao endorsementDao;
	@Autowired
	private SkillDao skillDao;
	@Autowired
	private UserDao userDao;

	@Transactional
	public DatabaseOperationStatus add(User user, User userEndorsed, Skill skill) {
		Endorsement endorsement = new Endorsement();
		endorsement.setEndorsedUserId(userEndorsed.getId());
		endorsement.setUserId(user.getId());
		endorsement.setSkillId(skill.getId());
		try {
			if (endorsementDao.checkEndorsement(endorsement)) {
				endorsementDao.add(endorsement);
				return DatabaseOperationStatus.SUCCESS;
			} else {
				return DatabaseOperationStatus.FAILURE;
			}
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
	}

	@Transactional
	public DatabaseOperationStatus update(User user, Endorsement endorsement) {

		try {
			// endorsementDao.update(user,endorsement);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus delete(int id) {
		try {
			endorsementDao.delete(id);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public Endorsement getEndorsement(int id) {

		return endorsementDao.getEndorsement(id);
	}

	@Transactional
	public Map<String, List<User>> getAllEndorsement(User user) {
		//List<User> userList = new ArrayList<User>();
		Map<String, List<User>> userIdMap = new HashMap<String, List<User>>();
		try {
			List<Skill> skillList = skillDao.getSkill(user);
			 userIdMap = endorsementDao
					.getAllEndorsement(skillList);
			/*List<Integer> userIdList = new ArrayList<Integer>();
			Iterator iterator = userIdMap.entrySet().iterator();
			while (iterator.hasNext()) {
				Map.Entry pair = (Map.Entry) iterator.next();
				System.out.println(pair.getKey() + " = " + pair.getValue());
				userIdList = (List<Integer>) pair.getValue();
				for (Integer userId : userIdList) {
					userList.add(userDao.getUser(userId));
				}
				iterator.remove(); // avoids a ConcurrentModificationException
			}*/

		} catch (HibernateException e) {
		}
		return userIdMap;
	}

	@Transactional
	public boolean checkEndorsement(Endorsement endorsement) {
		return endorsementDao.checkEndorsement(endorsement);
	}

	@Transactional
	public int getSkillEndorseMentCount(User user, Skill skill) {
		return endorsementDao.getSkillEndorseMentCount(user, skill);

	}

}
