package com.skillfinder.operations.crud;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.model.Achievements;
import com.skillfinder.model.Certificate;
import com.skillfinder.model.CommonData;
import com.skillfinder.model.Education;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;
import com.skillfinder.model.Work;
import com.skillfinder.service.AchievementService;
import com.skillfinder.service.CertificateService;
import com.skillfinder.service.CommonDataService;
import com.skillfinder.service.EducationService;
import com.skillfinder.service.EndorsementService;
import com.skillfinder.service.SkillService;
import com.skillfinder.service.WorkService;

@Repository
public class ReadOperation {

	@Autowired
	private CommonDataService commonDataService;
	@Autowired
	private EducationService educationService;
	@Autowired
	private EndorsementService endorsementService;
	@Autowired
	private SkillService skillService;
	@Autowired
	private WorkService workService;
	@Autowired
	private CertificateService certificateService;
	@Autowired
	private AchievementService achievementService;

	public List<Work> readWork(User user) {
		return workService.getWorkList(user);
	}

	public Education readEducation(User user) {
		return educationService.getEducation(user);
	}

	public CommonData readCommonData(User user) {
		return commonDataService.getCommonData(user);
	}

	public List<Skill> readSkills(User user) {
		return skillService.getSkill(user);
	}

	public List<Certificate> readCertificates(User user) {
		return certificateService.getCertificateList(user);
	}

	public List<Achievements> readWorkAchievements(Work work) {
		return achievementService.getAchievements(work);
	}

	public Map<String, List<Achievements>> readEducationAchievements(Education education) {
		return achievementService.getAchievements(education);
	}
}
