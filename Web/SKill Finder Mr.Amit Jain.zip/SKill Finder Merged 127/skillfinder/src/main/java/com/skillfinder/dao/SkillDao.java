/**
 * 
 */
package com.skillfinder.dao;

import java.util.List;

import com.skillfinder.model.Skill;
import com.skillfinder.model.User;

/**
 * @author jai shree krishna
 *
 */
public interface SkillDao {
	public boolean add(Skill skill);
	public void update(User user,Skill skill );
	public void delete(Skill skill);
	public List<Skill> getSkill(User user);
	public boolean checkSkill(Skill skill);
	public Skill getSkill(int id);
	public Skill getSkillList(User user);
	public List<User> search(String inputString); 
}
