package com.skillfinder.communication;

import com.skillfinder.exceptions.EmailSendingFailedException;

public class PasswordResetEmail {
	private String userEmail;
	private Email resetEmail;
	private String subject = "Reset SkillFinder Account Password";

	private String emailBody = "Reset Link";

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
		if (!userEmail.isEmpty()) {
			resetEmail.setRecieverEmailAddress(userEmail);
		}
	}

	public boolean send() throws EmailSendingFailedException {
		resetEmail.setEmailBody(emailBody);
		resetEmail.setSubject(subject);
		if (!userEmail.isEmpty()) {
			resetEmail.sendMail();
			return true;
		}
		return false;
	}
}
