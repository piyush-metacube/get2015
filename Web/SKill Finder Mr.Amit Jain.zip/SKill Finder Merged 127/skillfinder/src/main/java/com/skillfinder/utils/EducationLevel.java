package com.skillfinder.utils;

public enum EducationLevel {
	UG, PG, SE, SSE
}
