/**
 * 
 */
package com.skillfinder.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillfinder.dao.SeniorSecondaryEducationDao;
import com.skillfinder.model.SeniorSecondaryEducation;
import com.skillfinder.service.SeniorSecondaryEducationService;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author avinash
 *
 */
@Service
public class SeniorSecondaryEducationServiceImpl implements
		SeniorSecondaryEducationService {

	@Autowired
	private SeniorSecondaryEducationDao seniorSecondaryEducationDao;

	@Transactional
	public DatabaseOperationStatus add(SeniorSecondaryEducation education) {
		try {
			seniorSecondaryEducationDao.add(education);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus update(SeniorSecondaryEducation education) {
		try {
			seniorSecondaryEducationDao.update(education);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public SeniorSecondaryEducation getEducation(int id) {
		try {
			return seniorSecondaryEducationDao.getEducation(id);
		} catch (Exception e) {
			return null;
		}
	}

	@Transactional
	public List<SeniorSecondaryEducation> getAllEducation() {
		List<SeniorSecondaryEducation> seniorSecondaryEducationslist = new ArrayList<SeniorSecondaryEducation>();
		try {
			seniorSecondaryEducationslist = seniorSecondaryEducationDao
					.getAllEducation();
		} catch (HibernateException e) {
		}
		return seniorSecondaryEducationslist;
	}

}
