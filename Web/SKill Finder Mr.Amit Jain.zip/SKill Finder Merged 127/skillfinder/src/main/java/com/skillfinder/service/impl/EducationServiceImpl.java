/**
 * 
 */
package com.skillfinder.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillfinder.dao.EducationDao;
import com.skillfinder.model.Education;
import com.skillfinder.model.User;
import com.skillfinder.service.EducationService;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
@Service
public class EducationServiceImpl implements EducationService {

	@Autowired
	private EducationDao dao;

	@Transactional
	public DatabaseOperationStatus add(User user, Education education) {

		try {
			dao.add(user, education);
		} catch (Exception e) {
			return DatabaseOperationStatus.FAILURE;
		}

		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus update(Education education) {
		try {
			dao.update(education);
		} catch (Exception e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus delete(Education education) {
		try {
			dao.delete(education);
		} catch (Exception e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public Education getEducation(User user) {
		try {
			return dao.getEducation(user);
		} catch (Exception e) {
			return null;
		}
	}

}
