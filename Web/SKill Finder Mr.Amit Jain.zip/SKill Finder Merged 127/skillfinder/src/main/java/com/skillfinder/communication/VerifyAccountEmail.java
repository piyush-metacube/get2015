package com.skillfinder.communication;

public class VerifyAccountEmail {

}
