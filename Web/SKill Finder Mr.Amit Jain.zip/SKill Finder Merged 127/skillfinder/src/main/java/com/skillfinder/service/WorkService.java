/**
 * 
 */
package com.skillfinder.service;

import java.util.List;

import com.skillfinder.model.User;
import com.skillfinder.model.Work;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
public interface WorkService {
	public DatabaseOperationStatus add(Work work);
	public DatabaseOperationStatus update(Work work);
	public DatabaseOperationStatus delete(Work work);
	public List<Work> getWorkList(User user);
}
