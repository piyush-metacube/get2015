/**
 * project skill finder
 */
package com.skillfinder.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

/**
 * Class to store Work of respective User
 * 
 * @author Priyamvada
 *
 */
@Entity
public class Education {

	@Id
	@Column(name = "education_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@OneToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "user_id", unique = true)
	private User user;

	@OneToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "secondary_education_id")
	private SecondaryEducation secondaryEducation;

	@OneToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "senior_secondary_education_id")
	private SeniorSecondaryEducation seniorSecondaryEducation;

	@OneToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "under_graduate_education_id")
	private UnderGraduateEducation underGraduateEducation;

	@OneToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "post_graduate_education_id")
	private PostGraduateEducation postGraduateEducation;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public SecondaryEducation getSecondaryEducation() {
		return secondaryEducation;
	}

	public void setSecondaryEducation(SecondaryEducation secondaryEducation) {
		this.secondaryEducation = secondaryEducation;
	}

	public SeniorSecondaryEducation getSeniorSecondaryEducation() {
		return seniorSecondaryEducation;
	}

	public void setSeniorSecondaryEducation(
			SeniorSecondaryEducation seniorSecondaryEducation) {
		this.seniorSecondaryEducation = seniorSecondaryEducation;
	}

	public UnderGraduateEducation getUnderGraduateEducation() {
		return underGraduateEducation;
	}

	public void setUnderGraduateEducation(
			UnderGraduateEducation underGraduateEducation) {
		this.underGraduateEducation = underGraduateEducation;
	}

	public PostGraduateEducation getPostGraduateEducation() {
		return postGraduateEducation;
	}

	public void setPostGraduateEducation(
			PostGraduateEducation postGraduateEducation) {
		this.postGraduateEducation = postGraduateEducation;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime
				* result
				+ ((postGraduateEducation == null) ? 0 : postGraduateEducation
						.hashCode());
		result = prime
				* result
				+ ((secondaryEducation == null) ? 0 : secondaryEducation
						.hashCode());
		result = prime
				* result
				+ ((seniorSecondaryEducation == null) ? 0
						: seniorSecondaryEducation.hashCode());
		result = prime
				* result
				+ ((underGraduateEducation == null) ? 0
						: underGraduateEducation.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Education other = (Education) obj;
		if (id != other.id)
			return false;
		if (postGraduateEducation == null) {
			if (other.postGraduateEducation != null)
				return false;
		} else if (!postGraduateEducation.equals(other.postGraduateEducation))
			return false;
		if (secondaryEducation == null) {
			if (other.secondaryEducation != null)
				return false;
		} else if (!secondaryEducation.equals(other.secondaryEducation))
			return false;
		if (seniorSecondaryEducation == null) {
			if (other.seniorSecondaryEducation != null)
				return false;
		} else if (!seniorSecondaryEducation
				.equals(other.seniorSecondaryEducation))
			return false;
		if (underGraduateEducation == null) {
			if (other.underGraduateEducation != null)
				return false;
		} else if (!underGraduateEducation.equals(other.underGraduateEducation))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}
}
