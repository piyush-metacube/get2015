package com.skillfinder.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillfinder.dao.AchievementDao;
import com.skillfinder.model.Achievements;
import com.skillfinder.model.Education;
import com.skillfinder.model.User;
import com.skillfinder.model.Work;
import com.skillfinder.service.AchievementService;
@Service
public class AchievementsServiceImpl implements AchievementService{
	@Autowired
	AchievementDao achievementDao;
	@Transactional
	public Map<String, List<Achievements>> getAchievements(Education education) {
		return achievementDao.getAchievements(education);
	}

	@Transactional
	public List<Achievements> getAchievements(Work work) {
		return achievementDao.getAchievements(work);
	}

	@Transactional
	public void add( List<Achievements> achievementList) {
		achievementDao.add(achievementList);
		
	}

}
