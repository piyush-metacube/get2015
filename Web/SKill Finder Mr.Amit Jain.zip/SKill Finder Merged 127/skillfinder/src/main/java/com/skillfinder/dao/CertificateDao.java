/**
 * project skillfinder
 */
package com.skillfinder.dao;

import java.util.List;

import com.skillfinder.model.Certificate;
import com.skillfinder.model.User;

/**
 * DAO Interface for Certificate
 * 
 * @author priyamvada
 * @version %I %G
 *
 */
public interface CertificateDao {
	/**
	 * to add certificate of user
	 * 
	 * @param user
	 *            user whose certificate is to be added
	 * @param achievements
	 *            certificate to be added
	 */
	public void add(User user, Certificate certificate);

	public void update(User user, Certificate certificate);

	public void delete(Certificate certificate);

	public Certificate getCertificate(Certificate certificate);

	public List<Certificate> getCertificateList(User user);
}
