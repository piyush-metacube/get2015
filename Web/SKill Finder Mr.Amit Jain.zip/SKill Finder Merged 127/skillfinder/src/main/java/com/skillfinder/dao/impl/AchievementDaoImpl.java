/**
 * project skillfinder
 */
package com.skillfinder.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.AchievementDao;
import com.skillfinder.model.Achievements;
import com.skillfinder.model.Education;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;
import com.skillfinder.model.Work;

/**
 * DAO Interface for Achievement
 * 
 * @author priyamvada
 * @version %I %G
 *
 */
@Repository
public class AchievementDaoImpl implements AchievementDao {

	@Autowired
	private SessionFactory session;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.dao.AchievementDao#add(com.skillfinder.model.User,
	 * com.skillfinder.model.Achievements)
	 */
	@Override
	public void add(List<Achievements> achievementList) {
		for(Achievements currentAchievements : achievementList) {
			session.getCurrentSession().save(currentAchievements);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.dao.AchievementDao#update(com.skillfinder.model.User,
	 * com.skillfinder.model.Achievements)
	 */
	@Override
	public void update(User user, Achievements achievements) {
		session.getCurrentSession().update(achievements);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.dao.AchievementDao#delete(com.skillfinder.model.Achievements
	 * )
	 */
	@Override
	public void delete(Achievements achievements) {
		session.getCurrentSession().delete(getAchievements(achievements));

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.dao.AchievementDao#getAchievements(com.skillfinder.model
	 * .Achievements)
	 */
	@Override
	public Achievements getAchievements(Achievements achievements) {
		return (Achievements) session.getCurrentSession().get(
				Achievements.class, achievements.getId());
	}

	@Override
	public Map<String,List<Achievements>> getAchievements(Education education) {
		Map<String, List<Achievements>> achievementsMap= new HashMap<String, List<Achievements>>();
		String hqlString = "From Achievements where post_graduate_id = "+education.getPostGraduateEducation().getId();
		org.hibernate.Query query = session.getCurrentSession()
				.createQuery(hqlString);
		achievementsMap.put("PG", query.list());
		
		hqlString = "From Achievements where under_graduate_id = "+education.getUnderGraduateEducation().getId();
		query = session.getCurrentSession()
				.createQuery(hqlString);
		achievementsMap.put("UG", query.list());
		
		hqlString = "From Achievements where senior_secondary_education = "+education.getSeniorSecondaryEducation().getId();
		query = session.getCurrentSession()
				.createQuery(hqlString);
		achievementsMap.put("SSE", query.list());
		
		hqlString = "From Achievements where secondary_education_id = "+education.getSecondaryEducation().getId();
		query = session.getCurrentSession()
				.createQuery(hqlString);
		achievementsMap.put("SE", query.list());
		return achievementsMap;
	}

	@Override
	public List<Achievements> getAchievements(Work work) {
		String hqlString = "From Achievements where work_id = "+work.getId();
		org.hibernate.Query query = session.getCurrentSession()
				.createQuery(hqlString);
		return query.list();
	}
	

}
