package com.skillfinder.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillfinder.dao.PostGraduationEducationDao;
import com.skillfinder.model.PostGraduateEducation;
import com.skillfinder.service.PostGraduationEducationService;
import com.skillfinder.utils.DatabaseOperationStatus;

@Service
public class PostGraduationEducationServiceImpl implements
		PostGraduationEducationService {

	@Autowired
	private PostGraduationEducationDao graduationEducationDao;

	@Transactional
	public DatabaseOperationStatus add(PostGraduateEducation education) {
		try {
			graduationEducationDao.add(education);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus update(PostGraduateEducation education) {
		try {
			graduationEducationDao.update(education);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus delete(int id) {
		try {
			graduationEducationDao.delete(id);
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public PostGraduateEducation getEducation(int id) {
		try {
			return graduationEducationDao.getEducation(id);
		} catch (HibernateException e) {
			return null;
		}
	}

	@Transactional
	public List<PostGraduateEducation> getAllEducation() {
		List<PostGraduateEducation> postGraduateEducationsList = new ArrayList<PostGraduateEducation>();
		try {
			postGraduateEducationsList = graduationEducationDao
					.getAllEducation();
		} catch (HibernateException e) {
		}
		return postGraduateEducationsList;
	}

}
