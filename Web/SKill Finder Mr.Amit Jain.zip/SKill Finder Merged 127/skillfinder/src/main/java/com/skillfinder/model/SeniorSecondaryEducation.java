/**
 * project skill finder
 */
package com.skillfinder.model;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

/**
 * Class to store Senior Secondary Education of respective User
 * 
 * @author Priyamvada
 *
 */
@Entity
@Table(name = "Senior_secondary_education")
@Data
public class SeniorSecondaryEducation {

	@Id
	@Column(name = "senior_secondary_education_id")
	@GeneratedValue
	private int id;
	private String board;
	private int year;
	private String schoolName;

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBoard() {
		return board;
	}

	public void setBoard(String board) {
		this.board = board;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	
}
