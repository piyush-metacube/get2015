/**
 * 
 */
package com.skillfinder.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.SeniorSecondaryEducationDao;
import com.skillfinder.model.SecondaryEducation;
import com.skillfinder.model.SeniorSecondaryEducation;

/**
 * @author jai shree krishna
 *
 */
@Repository
public class SeniorSecondaryEducationDaoImpl implements SeniorSecondaryEducationDao{

	@Autowired
	private SessionFactory session;
	
	@Override
	public void add(SeniorSecondaryEducation education) {
		session.getCurrentSession().save(education);
		
		
	}

	@Override
	public void update(SeniorSecondaryEducation education) {
		session.getCurrentSession().update(education);
		
	}

	@Override
	public void delete(int id) {
		Criteria cr = session.openSession().createCriteria(SeniorSecondaryEducation.class);
		session.getCurrentSession().delete(getEducation(id));
		
	}

	@Override
	public SeniorSecondaryEducation getEducation(int id) {
		Criteria cr = session.getCurrentSession().createCriteria(SeniorSecondaryEducation.class);
		return (SeniorSecondaryEducation) cr.uniqueResult();
	}

	@Override
	public List<SeniorSecondaryEducation> getAllEducation() {
		Criteria cr = session.getCurrentSession().createCriteria(SeniorSecondaryEducation.class);
		return cr.list();
	}

}
