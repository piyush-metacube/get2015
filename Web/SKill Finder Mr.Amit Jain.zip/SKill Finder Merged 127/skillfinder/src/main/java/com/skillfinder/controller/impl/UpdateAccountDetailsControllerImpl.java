package com.skillfinder.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.skillfinder.controller.UpdateAccountDetailsController;
import com.skillfinder.model.requests.CertificateRequest;
import com.skillfinder.model.requests.CommonDetailsRequest;
import com.skillfinder.model.requests.EducationDataRequest;
import com.skillfinder.model.requests.SkillRequest;
import com.skillfinder.model.requests.UserCredential;
import com.skillfinder.model.requests.WorkExperienceRequest;
import com.skillfinder.model.responses.OperationResponse;
import com.skillfinder.operations.crud.UpdateOperation;
import com.skillfinder.service.CommonDataService;
import com.skillfinder.service.EducationService;
import com.skillfinder.service.EndorsementService;
import com.skillfinder.service.SkillService;
import com.skillfinder.service.UserService;
import com.skillfinder.service.WorkService;

@RestController
@RequestMapping("/accounts/update")
public class UpdateAccountDetailsControllerImpl implements
		UpdateAccountDetailsController {

	@Autowired
	private UpdateOperation updateOperation;
	@Autowired
	private UserService userService;
	@Autowired
	private CommonDataService commonDataService;
	@Autowired
	private EducationService educationService;
	@Autowired
	private EndorsementService endorsementService;
	@Autowired
	private SkillService skillService;
	@Autowired
	private WorkService workService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.controller.impl.UpdateAccountDetailsController#
	 * updateCredentials(com.skillfinder.model.requests.UserCredential)
	 */
	@Override
	@RequestMapping(value = "/usercredentials", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse updateCredentials(
			@RequestBody UserCredential userCredential) {
		OperationResponse operationResponse = updateOperation
				.updateCredentials(userCredential);
		return operationResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.controller.impl.UpdateAccountDetailsController#
	 * updateWorkExperience
	 * (com.skillfinder.model.requests.WorkExperienceRequest)
	 */
	@Override
	@RequestMapping(value = "/work", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse updateWorkExperience(
			@RequestBody WorkExperienceRequest workExperienceRequest) {
		OperationResponse OperationResponse = updateOperation
				.updateWork(workExperienceRequest);
		return OperationResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.controller.impl.UpdateAccountDetailsController#
	 * updateEducation(com.skillfinder.model.requests.EducationDataRequest)
	 */
	@Override
	@RequestMapping(value = "/education", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse updateEducation(
			@RequestBody EducationDataRequest educationDataRequest) {

		OperationResponse OperationResponse = updateOperation
				.updateEducation(educationDataRequest);
		return OperationResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.controller.impl.UpdateAccountDetailsController#
	 * updateCommonData(com.skillfinder.model.requests.CommonDetailsRequest)
	 */
	@Override
	@RequestMapping(value = "/commondata", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse updateCommonData(
			@RequestBody CommonDetailsRequest commonDetailsRequest) {
		OperationResponse OperationResponse = updateOperation
				.updateCommonDetails(commonDetailsRequest);
		return OperationResponse;
	}
	@Override
	@RequestMapping(value = "/certificate", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse updateCertificate(
			@RequestBody CertificateRequest certificateRequest) {

		OperationResponse OperationResponse = updateOperation
				.updateCertificate(certificateRequest);

		return OperationResponse;
	}

	@Override
	@RequestMapping(value = "/skill", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OperationResponse updateSkill(
			@RequestBody SkillRequest skillRequest) {

		OperationResponse OperationResponse = updateOperation
				.updateSkill(skillRequest);

		return OperationResponse;
	}

}
