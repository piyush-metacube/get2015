package com.skillfinder.model.requests;

public class WorkExperienceRequest {
	private String userId;
	private String companyName;
	private String workingFrom;
	private String workingTo;
	private String designation;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getWorkingFrom() {
		return workingFrom;
	}

	public void setWorkingFrom(String workingFrom) {
		this.workingFrom = workingFrom;
	}

	public String getWorkingTo() {
		return workingTo;
	}

	public void setWorkingTo(String workingTo) {
		this.workingTo = workingTo;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

}
