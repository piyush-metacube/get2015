package com.skillfinder.controller;

import com.skillfinder.model.requests.CertificateRequest;
import com.skillfinder.model.requests.CommonDetailsRequest;
import com.skillfinder.model.requests.EducationDataRequest;
import com.skillfinder.model.requests.SkillRequest;
import com.skillfinder.model.requests.UserCredential;
import com.skillfinder.model.requests.WorkExperienceRequest;
import com.skillfinder.model.responses.OperationResponse;

public interface UpdateAccountDetailsController {

	public OperationResponse updateCredentials(UserCredential userCredential);

	public OperationResponse updateWorkExperience(
			WorkExperienceRequest workExperienceRequest);

	public OperationResponse updateEducation(
			EducationDataRequest educationDataRequest);

	public OperationResponse updateCommonData(
			CommonDetailsRequest commonDetailsRequest);

	public OperationResponse updateSkill(SkillRequest skillRequest);

	public OperationResponse updateCertificate(
			CertificateRequest certificateRequest);

}