/**
 * 
 */
package com.skillfinder.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.CertificateDao;
import com.skillfinder.model.Certificate;
import com.skillfinder.model.User;
import com.skillfinder.model.Work;

/**
 * @author priyamvada
 *
 */
@Repository
public class CertificateDaoImpl implements CertificateDao {

	@Autowired
	private SessionFactory session;

	@Override
	public void add(User user, Certificate certificate) {
		session.getCurrentSession().save(certificate);
	}

	@Override
	public void update(User user, Certificate certificate) {
		session.getCurrentSession().update(certificate);
	}

	@Override
	public void delete(Certificate certificate) {
		session.getCurrentSession().delete(getCertificate(certificate));
	}

	@Override
	public Certificate getCertificate(Certificate certificate) {
		return (Certificate) session.getCurrentSession().get(Certificate.class,
				certificate.getId());
	}

	@Override
	public List<Certificate> getCertificateList(User user) {
		Criteria criteria1 = session.getCurrentSession().createCriteria(
				Certificate.class);
		Criteria criteria2 = criteria1.createCriteria("user");
		criteria2.add(Restrictions.eq("id", user.getId()));
		return (List<Certificate>) criteria2.list();
	}
}
