package com.skillfinder.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.UnderGraduateEducationDao;
import com.skillfinder.model.Skill;
import com.skillfinder.model.UnderGraduateEducation;

@Repository
public class UnderGrauateEducationDaoImpl implements UnderGraduateEducationDao {

	@Autowired
	private SessionFactory session;

	@Override
	public void add(UnderGraduateEducation education) {
		session.getCurrentSession().save(education);

	}

	@Override
	public void update(UnderGraduateEducation education) {
		session.getCurrentSession().update(education);

	}

	@Override
	public void delete(int id) {
		Criteria cr = session.openSession().createCriteria(UnderGraduateEducation.class);
		session.getCurrentSession().delete(getEducation(id));
	}

	@Override
	public UnderGraduateEducation getEducation(int id) {
		Criteria cr = session.getCurrentSession().createCriteria(UnderGraduateEducation.class);
		return (UnderGraduateEducation) cr.list();
	}

	@Override
	public List<UnderGraduateEducation> getAllEducation() {
		Criteria cr = session.getCurrentSession().createCriteria(UnderGraduateEducation.class);
		return cr.list();
	}

}
