package com.skillfinder.service;

import java.util.List;

import com.skillfinder.model.Certificate;
import com.skillfinder.model.User;
import com.skillfinder.utils.DatabaseOperationStatus;

public interface CertificateService {
	public DatabaseOperationStatus add(User user, Certificate certificate);

	public DatabaseOperationStatus update(User user, Certificate certificate);

	public DatabaseOperationStatus delete(Certificate certificate);

	public Certificate getCertificate(Certificate certificate);

	public List<Certificate> getCertificateList(User user);
}
