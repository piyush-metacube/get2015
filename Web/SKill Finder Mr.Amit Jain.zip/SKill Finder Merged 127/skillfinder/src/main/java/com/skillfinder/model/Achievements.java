/**
 * project skill finder
 */
package com.skillfinder.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

/**
 * Class to store Achievements of respective User
 * 
 * @author Priyamvada
 * @Version %I %G
 */
@Entity
@Table(name = "achievements")
@Data
public class Achievements {

	@Id
	@Column(name = "achievement_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column
	private int year;
	@Column
	private String headline;
	@Column
	private String description;
	@Column
	private String category;
	@ManyToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "under_graduate_id")
	private UnderGraduateEducation UnderGraduateEducation;
	
	@ManyToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "post_graduate_id")
	private PostGraduateEducation PostGraduateEducation;
	
	@ManyToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "senior_secondary_education_id")
	private SeniorSecondaryEducation seniorSecondaryEducation;
	
	@ManyToOne(cascade = { CascadeType.ALL, CascadeType.REMOVE })
	@JoinColumn(name = "secondary_education_id")
	private SecondaryEducation secondaryEducation;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getHeadline() {
		return headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Achievements [id=" + id + ", year=" + year + ", headline="
				+ headline + ", description=" + description + ", category="
				+ category + "]";
	}

}
