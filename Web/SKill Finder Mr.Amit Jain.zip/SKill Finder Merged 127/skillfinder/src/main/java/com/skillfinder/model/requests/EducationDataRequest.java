package com.skillfinder.model.requests;

import java.util.ArrayList;
import java.util.List;

public class EducationDataRequest {
	private String email;
	private String level;
	private String college;
	private Integer year;
	private String course;
	private String UserId;

	public String getUserId() {
		return UserId;
	}

	public void setUserId(String userId) {
		UserId = userId;
	}

	private List<AchievementRequest> achivements = new ArrayList<AchievementRequest>();

	/**
	 * 
	 * @return The email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * 
	 * @param email
	 *            The email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * 
	 * @return The level
	 */
	public String getLevel() {
		return level;
	}

	/**
	 * 
	 * @param level
	 *            The level
	 */
	public void setLevel(String level) {
		this.level = level;
	}

	/**
	 * 
	 * @return The college
	 */
	public String getCollege() {
		return college;
	}

	/**
	 * 
	 * @param college
	 *            The college
	 */
	public void setCollege(String college) {
		this.college = college;
	}

	/**
	 * 
	 * @return The year
	 */
	public Integer getYear() {
		return year;
	}

	/**
	 * 
	 * @param year
	 *            The year
	 */
	public void setYear(Integer year) {
		this.year = year;
	}

	/**
	 * 
	 * @return The course
	 */
	public String getCourse() {
		return course;
	}

	/**
	 * 
	 * @param course
	 *            The course
	 */
	public void setCourse(String course) {
		this.course = course;
	}

	/**
	 * 
	 * @return The achivements
	 */
	public List<AchievementRequest> getAchivements() {
		return achivements;
	}

	/**
	 * 
	 * @param achivements
	 *            The achivements
	 */
	public void setAchivements(List<AchievementRequest> achivements) {
		this.achivements = achivements;
	}

}
