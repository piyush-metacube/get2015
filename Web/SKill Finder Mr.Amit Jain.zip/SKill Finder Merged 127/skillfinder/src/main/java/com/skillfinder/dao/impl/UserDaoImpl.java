/**
 * 
 */
package com.skillfinder.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.UserDao;
import com.skillfinder.model.User;

/**
 * @author priyamvada
 *
 */
@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory session;

	@Override
	public boolean saveCredentials(User user) {
		System.out.println(user);
		session.getCurrentSession().save(user);
		return true;
	}

	@Override
	public void update(User user) {
		session.getCurrentSession().update(user);
	}

	@Override
	public void delete(User user) {
		Criteria criteria = session.openSession().createCriteria(User.class);
		session.getCurrentSession().delete(getUser(user));

	}

	@Override
	public User getUser(User user) {
		Criteria criteria = session.getCurrentSession().createCriteria(
				User.class);
		criteria.add(Restrictions.eq("userName", user.getId()));
		User resultUser = (User) criteria.uniqueResult();
		return resultUser;
	}

	@Override
	public User getUser(int userId) {
		Criteria criteria = session.getCurrentSession().createCriteria(
				User.class);
		criteria.add(Restrictions.eq("id", userId));
		User resultUser = (User) criteria.uniqueResult();
		System.out.println(resultUser);
		return resultUser;
	}

	@Override
	public List<User> getAllUser() {
		Criteria criteria = session.getCurrentSession().createCriteria(
				User.class);
		return criteria.list();
	}

	@Override
	public boolean checkLogin(User user) {

		String hql = "SELECT userName, password FROM User where userName = '"
				+ user.getUserName() + "' and password = '"
				+ user.getPassword() + "'";
		org.hibernate.Query query = session.getCurrentSession()
				.createQuery(hql);
		List<User> results = query.list();
		if (results.size() == 0) {
			return false;
		} else {
			return true;
		}
	}
	
	@Override
	public boolean checkUserExistence(User user) {

		String hql = "SELECT userName FROM User where userName = '"
				+ user.getUserName() + "'";
		org.hibernate.Query query = session.getCurrentSession()
				.createQuery(hql);
		List<User> results = query.list();
		if (results.size() == 0) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public List<User> search(String inputString) {
		String hql = "from User where userName = '"+inputString;
		org.hibernate.Query query = session.getCurrentSession()
				.createQuery(hql);
		List<User> userList = query.list();
		return userList;
	}
}
