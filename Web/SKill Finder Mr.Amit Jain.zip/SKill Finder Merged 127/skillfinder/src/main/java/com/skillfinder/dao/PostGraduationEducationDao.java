/**
 * 
 */
package com.skillfinder.dao;

import java.util.List;

import com.skillfinder.model.PostGraduateEducation;

/**
 * @author jai shree krishna
 *
 */
public interface PostGraduationEducationDao {
	public void add(PostGraduateEducation education );
	public void update(PostGraduateEducation education );
	public void delete(int id);
	public PostGraduateEducation getEducation(int id);
	public List<PostGraduateEducation> getAllEducation();
}
