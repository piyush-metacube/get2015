/**
 * 
 */
package com.skillfinder.service;

import java.util.List;

import com.skillfinder.model.SecondaryEducation;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author jai shree krishna
 *
 */
public interface SecondaryEducationService {
	public DatabaseOperationStatus add(SecondaryEducation education );
	public DatabaseOperationStatus update(SecondaryEducation education );
	//public void delete(int id);
	public SecondaryEducation getEducation(int id);
	public List<SecondaryEducation> getAllEducation();
}
