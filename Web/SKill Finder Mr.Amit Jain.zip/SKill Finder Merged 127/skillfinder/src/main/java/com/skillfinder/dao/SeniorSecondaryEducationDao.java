/**
 * 
 */
package com.skillfinder.dao;

import java.util.List;

import com.skillfinder.model.SeniorSecondaryEducation;

/**
 * @author jai shree krishna
 *
 */
public interface SeniorSecondaryEducationDao {
	public void add(SeniorSecondaryEducation education );
	public void update(SeniorSecondaryEducation education );
	public void delete(int id);
	public SeniorSecondaryEducation getEducation(int id);
	public List<SeniorSecondaryEducation> getAllEducation();
}
