/**
 * 
 */
package com.skillfinder.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.skillfinder.dao.SkillDao;
import com.skillfinder.model.CommonData;
import com.skillfinder.model.SeniorSecondaryEducation;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;

/**
 * @author jai shree krishna
 *
 */
@Repository
public class SkillDaoImpl implements SkillDao {

	@Autowired
	private SessionFactory session;

	@Override
	public boolean add(Skill skill) {
		if (session.getCurrentSession() == null) {
			session.getCurrentSession().save(skill);
		} else {
			session.getCurrentSession().save(skill);
		}
		return true;
	}

	@Override
	public boolean checkSkill(Skill skill) {
		String hql = "FROM Skill where name  = '" + skill.getName()
				+ "' and category = '" + skill.getCategory() + "'";
		org.hibernate.Query query = session.getCurrentSession()
				.createQuery(hql);
		List<Skill> results = query.list();
		for (Skill currentSkill : results) {
			if (currentSkill.getUser().getId() == skill.getUser().getId()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void update(User user, Skill skill) {
		session.getCurrentSession().update(skill);

	}

	@Override
	public void delete(Skill skill) {
		Criteria cr = session.openSession().createCriteria(Skill.class);
		session.getCurrentSession().delete(getSkill(skill.getId()));
	}

	@Override
	public Skill getSkill(int id) {
		Criteria cr = session.getCurrentSession().createCriteria(Skill.class);
		return (Skill) cr.uniqueResult();
	}

	@Override
	public List<Skill> getSkill(User user) {
		System.out.println("hii");
		Criteria criteria1 = session.getCurrentSession().createCriteria(
				Skill.class);
		Criteria criteria2 = criteria1.createCriteria("user");
		criteria2.add(Restrictions.eq("id", user.getId()));
		List<Skill> resultSkillsList = criteria2.list();
		System.out.println("hii;" + resultSkillsList.size());
		return resultSkillsList;
	}

	@Override
	public Skill getSkillList(User user) {
		Criteria criteria1 = session.getCurrentSession().createCriteria(
				Skill.class);
		Criteria criteria2 = criteria1.createCriteria("user");
		criteria2.add(Restrictions.eq("id", user.getId()));
		return ((Skill) criteria2.uniqueResult());
	}

	@Override
	public List<User> search(String inputString) {
		String hql = "Select User FROM Skill where name  = '" + inputString + "'";
		org.hibernate.Query query = session.getCurrentSession()
				.createQuery(hql);
		List<User> userList = query.list();
		return userList;
	}
}
