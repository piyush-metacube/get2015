/**
 * 
 */
package com.skillfinder.exceptions;

/**
 * @author Piyush
 *
 */
public class EmailSendingFailedException extends SkillFinderException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
