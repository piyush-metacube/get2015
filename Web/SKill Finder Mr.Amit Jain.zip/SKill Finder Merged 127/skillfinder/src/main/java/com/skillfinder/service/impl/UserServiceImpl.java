/**
 * 
 */
package com.skillfinder.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillfinder.dao.SkillDao;
import com.skillfinder.dao.UserDao;
import com.skillfinder.model.User;
import com.skillfinder.service.UserService;
import com.skillfinder.utils.DatabaseOperationStatus;

/**
 * @author avinash
 *
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	
	@Autowired
	private SkillDao skillDao;


	@Transactional
	public DatabaseOperationStatus saveCredentials(User user) {
		try {
			if (!userDao.checkLogin(user)) {
				userDao.saveCredentials(user);
			} else {
				return DatabaseOperationStatus.FAILURE;
			}
		} catch (HibernateException e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus update(User user) {
		try {
			userDao.update(user);
		} catch (Exception e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public DatabaseOperationStatus delete(User user) {
		try {
			userDao.delete(user);
		} catch (Exception e) {
			return DatabaseOperationStatus.FAILURE;
		}
		return DatabaseOperationStatus.SUCCESS;
	}

	@Transactional
	public User getUser(User user) {

		try {
			return userDao.getUser(user);
		} catch (Exception e) {
			return null;
		}
	}

	@Transactional
	public List<User> getAllUser() {
		List<User> userslists = new ArrayList<User>();
		try {
			userslists = userDao.getAllUser();
		} catch (Exception e) {

		}
		return userslists;
	}

	@Transactional
	public boolean checkLogin(User user) {
		try {
			return userDao.checkLogin(user);
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional
	public User getUser(int userId) {
		try {
			return userDao.getUser(userId);
		} catch (Exception e) {
			return null;
		}
	}

	@Transactional
	public boolean checkUserExistence(User user) {
		try {
			return userDao.checkUserExistence(user);
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public List<User> search(String inputString) {
		List<User> userList;
		try {
			userList = userDao.search(inputString);
			if(userList.size() == 0) {
				userList = skillDao.search(inputString);
			}
		}catch(Exception e) {
			return null;
		}
		return userList;
	}
}
