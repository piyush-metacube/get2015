/**
 * project skillfinder
 */
package com.skillfinder.dao;

import java.util.List;

import com.skillfinder.model.CommonData;
import com.skillfinder.model.User;

/**
 * @author priyamvada
 *
 */
public interface CommonDataDao {
	public void add(User user, CommonData commonData);

	public void update(User user, CommonData commonData);

	public void delete(CommonData commonData);

	public CommonData getCommonData(User user);
	
	public CommonData getCommonData(CommonData commonData);

	public CommonData get(int userId);

}
