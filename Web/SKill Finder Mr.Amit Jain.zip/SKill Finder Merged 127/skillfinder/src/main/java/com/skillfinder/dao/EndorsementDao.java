/**
 * 
 */
package com.skillfinder.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.skillfinder.model.Endorsement;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;

/**
 * @author jai shree krishna
 *
 */
public interface EndorsementDao {
	public boolean add(Endorsement endorsement);
	public void delete(int id);
	public Endorsement getEndorsement(int id);
	public  Map<String, List<User>> getAllEndorsement(List<Skill> skillList);
	public boolean checkEndorsement(Endorsement endorsement);
	public int getSkillEndorseMentCount(User user,Skill skill);
}
