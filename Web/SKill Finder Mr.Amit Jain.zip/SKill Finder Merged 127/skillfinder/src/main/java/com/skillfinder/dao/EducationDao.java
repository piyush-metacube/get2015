/**
 * 
 */
package com.skillfinder.dao;

import java.util.List;

import com.skillfinder.model.Education;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;

/**
 * @author jai shree krishna
 *
 */
public interface EducationDao {
	public void add(User user,Education education );
	public void update(Education education );
	public void delete(Education education);
	public Education getEducation(Education education);
	public Education getEducation(User user);
}
