package com.skillfinder.controller.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.skillfinder.controller.ReadAccountDetailsController;
import com.skillfinder.model.Achievements;
import com.skillfinder.model.Certificate;
import com.skillfinder.model.Education;
import com.skillfinder.model.Skill;
import com.skillfinder.model.User;
import com.skillfinder.model.Work;
import com.skillfinder.operations.crud.ReadOperation;
import com.skillfinder.service.AchievementService;
import com.skillfinder.service.CertificateService;
import com.skillfinder.service.CommonDataService;
import com.skillfinder.service.EducationService;
import com.skillfinder.service.EndorsementService;
import com.skillfinder.service.SkillService;
import com.skillfinder.service.UserService;
import com.skillfinder.service.WorkService;

@RestController
@RequestMapping("accounts/getdata")
public class ReadAccountDetailsControllerImpl implements
		ReadAccountDetailsController {
	@Autowired
	private ReadOperation readOperation
	;
	@Autowired
	private UserService userService;
	@Autowired
	private CommonDataService commonDataService;
	@Autowired
	private EducationService educationService;
	@Autowired
	private EndorsementService endorsementService;
	@Autowired
	private SkillService skillService;
	@Autowired
	private WorkService workService;
	@Autowired
	private CertificateService certificateService;
	@Autowired
	private AchievementService read;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.skillfinder.controller.impl.ReadAccountDetailsController#
	 * readWorkExperience(java.lang.String)
	 */
	@Override
	@RequestMapping(value = "/work/{username}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Work> readWorkExperience(
			@PathVariable("username") String userName) {

		User user = new User();
		user.setUserName(userName);

		return workService.getWorkList(user);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.ReadAccountDetailsController#readEducation
	 * (java.lang.String)
	 */
	@Override
	@RequestMapping(value = "/education/{username}", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody Education readEducation(
			@PathVariable("username") String userName) {
		User user = new User();
		user.setUserName(userName);
		return educationService.getEducation(user);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.ReadAccountDetailsController#readCommonData
	 * (java.lang.String)
	 */
	@Override
	@RequestMapping(value = "/commondata/{username}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody com.skillfinder.model.CommonData readCommonData(
			@PathVariable("username") String userName) {
		User user = new User();
		user.setUserName(userName);

		return commonDataService.getCommonData(user);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.skillfinder.controller.impl.ReadAccountDetailsController#readEndorsement
	 * (java.lang.String)
	 */
	@Override
	@RequestMapping(value = "/endorsement/{username}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Map<String, List<User>> readEndorsement(
			@PathVariable("username") String userName) {

		User user = new User();
		user.setUserName(userName);
		return endorsementService.getAllEndorsement(user);
	}

	@Override
	@RequestMapping(value = "/skill/{username}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Skill> readSkill(
			@PathVariable("username") String userName) {

		User user = new User();
		user.setUserName(userName);
		return skillService.getSkill(user);
	}

	@Override
	@RequestMapping(value = "/certificate/{username}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Certificate> readCertificate(
			@PathVariable("username") String userName) {

		User user = new User();
		user.setUserName(userName);
		return certificateService.getCertificateList(user);
	}

	@Override
	@RequestMapping(value = "/achievements/work/{username}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Achievements> readWorkAchievement(
			@PathVariable("username") String userName) {

		User user = new User();
		user.setUserName(userName);
		Work work = new Work();
		work.setUser(user);
		return readOperation.readWorkAchievements(work);
	}

	@Override
	@RequestMapping(value = "/achievements/education/{username}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Map<String, List<Achievements>> readEducationalAchievement(
			@PathVariable("username") String userName) {

		User user = new User();
		user.setUserName(userName);
		Education education = new Education();
		education.setUser(user);
		return readOperation.readEducationAchievements(education);
	}
}
