/**
 * 
 */
package com.skillfinder.dao;

import java.util.List;

import com.skillfinder.model.UnderGraduateEducation;

/**
 * @author jai shree krishna
 *
 */
public interface UnderGraduateEducationDao {
	public void add(UnderGraduateEducation education );
	public void update(UnderGraduateEducation education );
	public void delete(int id);
	public UnderGraduateEducation getEducation(int id);
	public List<UnderGraduateEducation> getAllEducation();
}
