package com.skillfinder.model.requests;

public class AchievementRequest {
	private String achivementYear;
	private String achivementTitle;
	private String achivementDescription;

	public String getAchivementYear() {
		return achivementYear;
	}

	public void setAchivementYear(String achivementYear) {
		this.achivementYear = achivementYear;
	}

	public String getAchivementTitle() {
		return achivementTitle;
	}

	public void setAchivementTitle(String achivementTitle) {
		this.achivementTitle = achivementTitle;
	}

	public String getAchivementDescription() {
		return achivementDescription;
	}

	public void setAchivementDescription(String achivementDescription) {
		this.achivementDescription = achivementDescription;
	}

}
