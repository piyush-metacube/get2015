package com.skillfinder.controlBox;

public class ApplicationLoggingConfiguration {

	public static boolean debugLogging = true;
	public static boolean releaseLogging = true;
}
